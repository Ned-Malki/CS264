JobID: cp264oc-202405-lab8-a8
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab8

T1 BST
T1.1 [2/2/*] Read and test BST example

T2 AVL trees
T2.1 [4/4/*] Read and test AVL examples

T3 Red-Black-tree
T3.1 [2/2/*] Read and test Red-Black-tree

T4 Splay trees
T4.1 [2/2/*] Read and test Splay tree





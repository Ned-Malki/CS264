/* 
* Code example for CP264 Data Structures II
* Simple/singly linked list class test example 
* HBF 
*/

#include <stdio.h>
#include <stdlib.h>

// Uncomment these lines to test memory leaking
//#define usefree
//#define test

#ifdef test
#include <Windows.h> // for Sleep(ms) in memory leak testing
#endif

struct node {
    int data;
#ifdef test
    double ddata[1000]; // For memory leak test
#endif
    struct node *next;
};

struct node* new_node(int);
int get_data(struct node *);
void set_data(struct node *, int);
int length(struct node *);
void display_forward_iterative(struct node *);
void display_forward_recursive(struct node *);
void display_backward_recursive(struct node *);
void display_backward_iterative(struct node *); // Using additional linked list as stack
struct node *search(struct node *, int);
void insert_node_beg(struct node **, struct node*);
void insert_beg(struct node **, int);
void insert_end(struct node **, int);
void insert_after(struct node **, struct node *, int);
int delete_beg(struct node **);
int delete_end(struct node **);
int delete(struct node **, int);
void clean(struct node **); 

int main() {
    struct node *start = NULL;
    struct node *np; 

    np = new_node(2);
    insert_node_beg(&start, np);
    insert_beg(&start, 1);
    insert_end(&start, 3);
    insert_end(&start, 4);
    insert_end(&start, 5);
  
    np = new_node(6);
    insert_after(&start, np, 4);
    display_forward_iterative(start);
  
    np = search(start, 4);
    if (np != NULL) {
        printf("Value found: %d\n", get_data(np));
    } else {
        printf("Value not found\n");
    }
  
    printf("Delete beginning\n");
    delete_beg(&start);
    display_forward_iterative(start);
  
    printf("Delete end\n");
    delete_end(&start);
    display_forward_iterative(start);
  
    printf("Delete node of value 4\n");
    delete(&start, 4);
    display_forward_iterative(start);
 
    printf("Display forward (recursive)\n");
    display_forward_recursive(start);
  
    printf("Display backward (recursive)\n");
    display_backward_recursive(start);
 
    printf("Display backward (iterative), using additional linked list\n");
    display_backward_iterative(start);  
    clean(&start);
    
#ifdef test
    int i;
    for (i = 0; i < 100000; i++) {
        insert_beg(&start, 1);
        delete(&start, 1);
        Sleep(5);
    }
#endif  
    return 0;
}

struct node* new_node(int num) {
    struct node *np = (struct node *) malloc(sizeof(struct node));
    if (np == NULL) return NULL;
    np->data = num;
    np->next = NULL;  
    return np;
}

int get_data(struct node *np) {
    return np->data;
}

void set_data(struct node *np, int num) {
    np->data = num;
}

void insert_node_beg(struct node **startp, struct node* new_np) {
    new_np->next = *startp;
    *startp = new_np;
}

void insert_beg(struct node **startp, int num) {
    struct node* np = (struct node *)malloc(sizeof(struct node));
    if (np == NULL) { printf("malloc failed"); return; }
    np->data = num;
    np->next = *startp;
    *startp = np;
}

void insert_end(struct node **startp, int num) {
    struct node *np = (struct node *) malloc(sizeof(struct node));
    if (np == NULL) { printf("malloc failed"); return; }
    np->data = num;
    np->next = NULL;  
  
    if (*startp == NULL) {
        *startp = np;
    } else {
        struct node *p = *startp;
        while (p->next != NULL) {
            p = p->next;
        }
        p->next = np;
    }  
}

void insert_after(struct node **startp, struct node* new_np, int num) {
    if (*startp == NULL) {
        *startp = new_np;
        return;
    }
  
    struct node *np = *startp;
    while (np != NULL && np->data != num) {
        np = np->next;
    }
  
    if (np == NULL) { // If not found, insert at end
        insert_end(startp, new_np->data);
        free(new_np);
    } else { // Insert after found node
        new_np->next = np->next;
        np->next = new_np; 
    }
}

int delete_beg(struct node **startp) {
    if (*startp == NULL) return 0;
  
    struct node *np = *startp;
    *startp = np->next;
    free(np);
    return 1;
}

int delete_end(struct node **startp) {
    if (*startp == NULL) return 0;
  
    struct node *np = *startp;
    struct node *prev = NULL;
  
    while (np->next != NULL) {
        prev = np;
        np = np->next;
    }
  
    if (prev == NULL) {
        *startp = NULL;
    } else {
        prev->next = NULL;
    }
  
    free(np);
    return 1;
}

int delete(struct node **startp, int num) {
    struct node *np = *startp;
    struct node *prev = NULL;

    while (np != NULL && np->data != num) {
        prev = np;
        np = np->next;
    }
  
    if (np == NULL) return 0;
  
    if (prev == NULL) {
        *startp = np->next;
    } else {
        prev->next = np->next;
    }
  
    free(np);
    return 1;
}

struct node* search(struct node *start, int num) {
    while (start != NULL && start->data != num) {
        start = start->next;
    }
    return start;
}

void display_forward_iterative(struct node *start) {
    printf("Value Address\n");
    while (start != NULL) {
        printf("%5d %p\n", start->data, (void*)start);
        start = start->next;
    }
}

void display_forward_recursive(struct node *start) {
    if (start == NULL) return;
    printf("%5d %p\n", start->data, (void*)start);
    display_forward_recursive(start->next);
}

void display_backward_recursive(struct node *start) {
    if (start == NULL) return;
    display_backward_recursive(start->next);
    printf("%5d %p\n", start->data, (void*)start);
}

void display_backward_iterative(struct node *start) {
    if (start == NULL) return;
    struct node *stk = NULL, *ptr;
    while (start != NULL) {
        insert_beg(&stk, start->data);
        start = start->next;
    }
  
    while (stk != NULL) {
        printf("%5d %p\n", stk->data, (void*)stk);
        ptr = stk;
        stk = stk->next;
        free(ptr);
    }
}

int length(struct node *start) {
    int len = 0;
    while (start != NULL) {
        len++;
        start = start->next;
    }
    return len;
}

void clean(struct node **startp) {
    struct node *temp, *np = *startp;
    while (np != NULL) {
        temp = np;
        np = np->next;
        free(temp);
    }
    *startp = NULL;
}

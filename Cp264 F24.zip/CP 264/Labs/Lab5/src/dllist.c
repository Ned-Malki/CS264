#include <stdio.h>
#include <stdlib.h>
#include "dllist.h"

node *new_node(int num) {
    node *np = (node *) malloc(sizeof(node));
    np->data = num;
    np->prev = NULL;
    np->next = NULL;
    return np;
}

node *search(dllist *dlp, int value) {
    if (dlp == NULL) return NULL;
    node *np = dlp->head;
    while (np != NULL && np->data != value) {
        np = np->next;
    }
    return np;
}

void insert_beg(dllist *dlp, node *np) {
    if (dlp == NULL) return;
    if (dlp->head == NULL) {
        dlp->head = np;
        dlp->tail = np;
    } else {
        dlp->head->prev = np;
        np->next = dlp->head;
    }
    dlp->head = np;
    np->prev = NULL;
}

void insert_end(dllist *dlp, node *np) {
    if (dlp == NULL) return;
    if (dlp->head == NULL) {
        dlp->head = np;
        np->prev = NULL;
    } else {
        dlp->tail->next = np;
        np->prev = dlp->tail;
    }
    dlp->tail = np;
    np->next = NULL;
}

void delete_node(dllist *dlp, int value) {
    if (dlp == NULL) return;
    node *np = dlp->head;

    while (np != NULL && np->data != value) {
        np = np->next;
    }

    if (np == NULL) return;
    else if (np->prev == NULL) {
        dlp->head = np->next;
        if (dlp->head != NULL) {
            dlp->head->prev = NULL;
        }
    } else {
        np->prev->next = np->next;
    }

    if (np->next == NULL) {
        dlp->tail = np->prev;
    } else {
        np->next->prev = np->prev;
    }

    free(np);
}

void display_forward(dllist dl) {
    if (dl.head == NULL) {
        printf("empty\n");
        return;
    }
    node *np;
    for (np = dl.head; np != NULL; np = np->next) {
        printf("%d\n", np->data);
    }
}

void display_backward(dllist dl) {
    if (dl.head == NULL) {
        printf("empty\n");
        return;
    }
    node *np;
    for (np = dl.tail; np != NULL; np = np->prev) {
        printf("%d\n", np->data);
    }
}

void clean(dllist *dlp) {
    if (dlp == NULL) return;
    node *temp, *np = dlp->head;

    while (np != NULL) {
        temp = np;
        np = np->next;
        free(temp);
    }
    dlp->head = NULL;
    dlp->tail = NULL;
}

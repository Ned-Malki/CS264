#ifndef DLLIST_H
#define DLLIST_H

typedef struct node {
    int data;
    struct node *next;
    struct node *prev;
} node;

typedef struct dllist {
    node *head;
    node *tail;
} dllist;

node *new_node(int);
node *search(dllist *, int);
void insert_beg(dllist *, node *);
void insert_end(dllist *, node *);
void delete_node(dllist *, int);
void display_forward(dllist);
void display_backward(dllist);
void clean(dllist *);

#endif

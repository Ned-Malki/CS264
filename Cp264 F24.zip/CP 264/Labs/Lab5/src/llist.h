/* 
* Code example for CP264 Data Structures II
* header file of linked list design
* HBF 
*/
#ifndef LLIST
#define LLIST

#include <stdio.h>
#include <stdlib.h>

/**
 * linked list node structure
 * data - int type data hold by structure
 * next - Pointer pointing to next node of linked list
 */
struct node {
  int data;
  struct node *next;
};

typedef struct node node; 

/**
 * Display linked list.
 * @param start Pointer to the first node of linked list.
 */
void display(node *start);

node *new_node(int);
int get_data(node *start);
void set_data(node *start, int);
void insert_beg(node **startp, int num);
void insert_end(node **startp, int num);
node *search(node *start, int num);
int delete(node **startp, int num);
int length(node *start);
void clean(node **startp);

#endif

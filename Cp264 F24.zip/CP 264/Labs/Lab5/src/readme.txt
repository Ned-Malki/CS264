JobID: cp264oc-202405-lab5-a5
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab5

T1 Simple/singly linked list
T1.1 [2/2/*] Test singly linked list examples

T2 Linked list design
T2.1 [2/2/*] Design and implement linked list

T3 Doubly linked list
T3.1 [3/3/*] Work on doubly linked list

T4 Circular linked list
T4.1 [3/3/*] Work on circular linked list

A5

Q1 [12/12/*] Record data processing by singly linked list

Q2 [10/10/*] Doubly linked list

Q3 [8/8/*] Big integer type

Total: [40/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  

Q1:

Had some trouble when making makefile for it, no issues otherwise


Q2 output:

Had to merge this makefile witht eh voerall one since VScode did not appreciate two makefiles in the same folder for some reason

Q3 output:

Had no trouble breaking it up into different files, make file was easy to develop

Q4:
Had no trouble breaking it up into different files, make file was easy to develop

MAKEFILE:

Had trouble with the fact that Q2 alreqady had a makefile, so I merged them together. Also makefile did not appreciate Q1 as it wanted a sllist_main.c file


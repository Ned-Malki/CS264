#ifndef CLLIST_H
#define CLLIST_H

typedef struct node {
    int data;
    struct node *next;
} node;

void display(node *);
node *search(node *, int);
void insert(node **, int);
void delete(node **);
void clean(node **);

#endif

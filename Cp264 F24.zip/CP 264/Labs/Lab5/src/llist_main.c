/* 
* Code example for CP264 Data Structures II
* Testing the linked list data structure
* HBF 
*/
#include "llist.h"

int main() {
  node *start = NULL;
  node *np; 
  insert_beg(&start, 2);  
  insert_beg(&start, 1);
  insert_end(&start, 3);
  insert_end(&start, 4);
  display(start);
  int key = 4;
  np = search(start, key);
  if (np)
    printf("found: %d\n", get_data(np));
  else
	printf("not found: %d\n", key);  
  
  printf("Delete node: %d\n", key);
  delete(&start, key);
  display(start);
  clean(&start);
  display(start);

  return 0;
}

/*
gcc llist.h llist.c list_main.c -o test
test

data:1, address:11874056
data:2, address:11874040
data:3, address:11874072
data:4, address:11874088
found: 4
Delete node: 4
data:1, address:11874056
data:2, address:11874040
data:3, address:11874072
empty
*/

#include <stdio.h>
#include "dllist.h"

int main() {
    dllist dl = {0};

    int i;
    for (i = 1; i <= 4; i++) {
        insert_end(&dl, new_node(i));
    }

    /* print the dllist */
    printf("print doubly linked list forward\n");
    display_forward(dl);

    printf("print doubly linked list backward\n");
    display_backward(dl);

    insert_beg(&dl, new_node(10));
    printf("print forward after insert at beginning\n");
    display_forward(dl);

    node *np = new_node(20);
    insert_end(&dl, np);
    printf("print forward after insert at end\n");
    display_forward(dl);

    np = search(&dl, 20);
    if (np) printf("find %d\n", np->data);

    delete_node(&dl, 20);
    printf("print forward after remove node\n");
    display_forward(dl);

    clean(&dl);
    printf("dl has been deleted\n");
    display_forward(dl);

    return 0;
}

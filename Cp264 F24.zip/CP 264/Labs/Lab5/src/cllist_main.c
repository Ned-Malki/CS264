#include <stdio.h>
#include "cllist.h"

int main() {
    node *start = NULL;
    printf("\ninsert:\n");
    insert(&start, 1);
    insert(&start, 2);
    insert(&start, 3);
    insert(&start, 4);
    display(start);
    
    int key = 2;
    printf("\nsearch: %d\n", key);
    node *ptr = search(start, key);
    if (ptr)
        printf("found: %d\n", ptr->data);
    else
        printf("not found: %d\n", key);
    
    printf("\ndelete:\n");
    delete(&start);
    display(start);
    
    printf("\nclean:\n");
    clean(&start);
    display(start);
    
    return 0;
}


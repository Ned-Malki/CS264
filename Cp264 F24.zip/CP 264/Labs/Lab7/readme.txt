JobID: cp264oc-202405-lab7
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work. (does it really apply here?)

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab7

T1 Binary trees
T1.1 [4/4/*] Read and test simple binary tree

T2 Expression tree
T2.1 [2/2/*] Read and test expression tree   

T3 Huffman tree
T3.1 [2/2/*] Read and test Huffman tree      

Total: [10/10/*]




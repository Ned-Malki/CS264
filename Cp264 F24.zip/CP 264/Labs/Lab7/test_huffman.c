#include <stdio.h>
#include <stdlib.h>
#include "huffman.c"


extern void compressFile(FILE *input, FILE *output, int codeTable[]);
extern void decompressFile(FILE *input, FILE *output, Node *tree);
extern void buildHuffmanTree(Node **tree);
extern void fillTable(int codeTable[], Node *tree, int Code);
extern void invertCodes(int codeTable[], int codeTable2[]);

void run_tests() {  // New function to run the tests
    Node *tree;
    int codeTable[27], codeTable2[27];

    // Build Huffman Tree
    buildHuffmanTree(&tree);
    fillTable(codeTable, tree, 0);
    invertCodes(codeTable, codeTable2);

    // Test Compression
    FILE *input = fopen("test.txt", "r");
    if (!input) {
        fprintf(stderr, "Could not open test.txt for reading.\n");
        return;
    }

    FILE *output = fopen("compressed_output.bin", "wb");
    if (!output) {
        fclose(input);
        fprintf(stderr, "Could not open compressed_output.bin for writing.\n");
        return;
    }

    compressFile(input, output, codeTable2);
    fclose(input);
    fclose(output);

    // Test Decompression
    input = fopen("compressed_output.bin", "rb");
    if (!input) {
        fprintf(stderr, "Could not open compressed_output.bin for reading.\n");
        return;
    }

    output = fopen("decompressed_output.txt", "w");
    if (!output) {
        fclose(input);
        fprintf(stderr, "Could not open decompressed_output.txt for writing.\n");
        return;
    }

    decompressFile(input, output, tree);
    fclose(input);
    fclose(output);

    printf("Compression and Decompression completed successfully.\n");
}
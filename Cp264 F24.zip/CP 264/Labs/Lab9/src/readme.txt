JobID: cp264oc-202405-lab9
Name: type your name here
ID: type your student ID here

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation values, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab9

T1 Hash tables
T1.1 [5/5/*] Read and test hash tables

T2 Heaps
T2.1 [5/5/*] Read and test Heaps

Total: [10/10/*]


=======================================================================      
Copy and paste the console output of your public test below. 
This will help markers to mark your program if it fails the marking test.  

T1 output:
Insert into heap:Display heap:
19 18 13 16 17 10 12 9 15 8 7 1 5 4 11 0 6 3 14 2 
Sequece of find_max and delete_max:
19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0 
Heap sort testing
Before heap sort:
7 9 13 18 10 12 4 18 3 9 0 5 12 2 7 3 7 9 0 12 
After heap sort:
0 2 0 3 3 4 5 7 7 7 9 9 9 10 12 12 12 13 18 18 % 

hash table after insertion
size:  20
count: 10
hash data:
index: list of the data of the same hash index
 1: (1,20) 
 2: (2,25) (2,70) (42,80) 
 4: (4,25) 
12: (12,44) 
13: (13,78) 
14: (14,32) 
17: (17,11) (37,97) 

search data by key 37
Find data element: (37, 97)
delete data by key 37
Find data element: (1639465184, 36145)
size:  20
count: 9
hash data:
index: list of the data of the same hash index
 1: (1,20) 
 2: (2,25) (2,70) (42,80) 
 4: (4,25) 
12: (12,44) 
13: (13,78) 
14: (14,32) 
17: (17,11) 

T2 output:
min-heap by linked binary tree representation
complete binary tree after heap insertions
|___15 225
    |___13 169
        |___12 144
            |___11 121
            |___4 16
        |___10 100
            |___5 25
            |___1 1
    |___14 196
        |___8 64
            |___7 49
            |___2 4
        |___9 81
            |___3 9
            |___6 36
                |___0 0
complete binary tree after heap deletion (delete min)
|___7 49
    |___5 25
        |___4 16
        |___1 1
    |___6 36
        |___2 4
        |___3 9
            |___0 0
            


JobID: cp264oc-202405-lab10
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab10

T1 Graph data structure and operations
T1.1 [4/4/*] Read & test graph data structure

T2 Minimum spanning tree
T2.1 [2/2/*] Read and test Kruskal algorithm 
T2.2 [2/2/*] Read and test Prim algorithm    

T3 Shortest path problem
T3.1 [2/2/*] Read and test Dijkstra algorithm

Total: [10/10/*]

=======================================================================      
Copy and paste the console output of your public test below. 
This will help markers to mark your program if it fails the marking test.  



 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗     ██╗       
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝    ███║    ██╗
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║       ╚██║    ╚═╝
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║        ██║    ██╗
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║        ██║    ╚═╝
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝        ╚═╝       

adjlist:

Display Graph:
node id : list of neighbor node id
0 : 1
1 : 2
2 : 3
3 : 4
4 : 5
5 : 6
6 : 7
7 : 8
8 : 9
9 : 0
Reach count: 10

Display Graph:
node id : list of neighbor node id
0 :
1 : 2
2 :
3 : 4
4 :
5 : 6
6 :
7 : 8
8 :
9 : 0
Reach count: 1

Graph is deleted
Generate random graph:
Display Graph:
node id : list of neighbor node id
0 : 1 6 4 2 9
1 : 8 4 9 5 0 6 3
2 : 8 6
3 :
4 : 3 0 8 7 1 9 6
5 : 2 6 8 9
6 : 9
7 : 2 1 4 9
8 : 3 6 5 1 7 2 0 4
9 : 1 0 5 6 7 4 8 3
bredth-first-order: 0 1 6 4 2 9 8 5 3 7
bfs(7)=7

depth-first-order: 0 9 3 8 7 5 2 4 6 1
Connectivity:
connected

depth-first-order by recursive algorithm:
0 1 8 3 6 9 5 2 7 4
Graph is deleted

ADJMATRIX:
simple_graph_adjmatrix.c: In function 'randomGraph':
simple_graph_adjmatrix.c:43:9: warning: implicit declaration of function 'time' [-Wimplicit-function-declaration]
   43 |   srand(time(NULL));
      |         ^~~~
   0 1 2 3 4 5 6 7 8 9 
0  0 0 1 0 0 1 0 0 0 0
1  0 0 0 1 1 1 1 1 1 0
2  1 0 0 0 1 1 1 0 1 1
3  0 1 0 0 1 1 1 0 0 0
4  0 1 1 1 0 1 0 1 0 1
5  1 1 1 1 1 0 1 0 0 0
6  0 1 1 1 0 1 0 1 0 1
7  0 1 0 0 1 0 1 0 0 0
8  0 1 1 0 0 0 0 0 0 0
9  0 0 1 0 1 0 1 0 0 0

BFS:
0 2 5 4 6 8 9 1 3 7 
DFS:
0 2 4 1 3 5 6 7 9 8 
DFS recursion:
0 2 4 1 3 5 6 7 9 8 



 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗    ██████╗        
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝    ╚════██╗    ██╗
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║        █████╔╝    ╚═╝
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║       ██╔═══╝     ██╗
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║       ███████╗    ╚═╝
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝       ╚══════╝       

PRIM:

   0     1     2     3     4     
0  9999  7     3     9999  9999 
1  7     9999  4     9     11   
2  3     4     9999  10    9999 
3  9999  9     10    9999  9999 
4  9999  9999  9999  9999  9999 

The edges of the MST are
0 2
2 1
1 3
1 4
The total cost of the MST is 27


KRUSKAL:

(2      0       1)
(5      3       2)
(1      0       3)
(4      1       3)
(5      2       4)

Cost of the spanning tree=13





 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗    ██████╗        
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝    ╚════██╗    ██╗
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║        █████╔╝    ╚═╝
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║        ╚═══██╗    ██╗
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║       ██████╔╝    ╚═╝
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝       ╚═════╝        

KRUSKAL:

Shortest path tree: root: 0, edge-list: {0, 1},{1, 2},{0, 3},{2, 4}
shortest-path(0, 0): length: 0, edge-list: 
shortest-path(0, 1): length: 10, edge-list: {0, 1}
shortest-path(0, 2): length: 60, edge-list: {0, 1}, {1, 2}
shortest-path(0, 3): length: 30, edge-list: {0, 3}
shortest-path(0, 4): length: 70, edge-list: {0, 1}, {1, 2}, {2, 4}


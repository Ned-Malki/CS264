/* ctype.h */

#ifndef CTYPE_H
#define CTYPE_H

// Structure for complex number
typedef struct {
  int real;
  int imaginary;
} COMPLEX;

// Function prototypes
void print_complex(COMPLEX x);
COMPLEX add(COMPLEX x, COMPLEX y);
COMPLEX subtract(COMPLEX x, COMPLEX y);
COMPLEX multiply(COMPLEX x, COMPLEX y);

#endif

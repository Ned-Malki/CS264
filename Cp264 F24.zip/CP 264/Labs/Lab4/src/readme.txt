JobID: cp264oc-202405-lab4-a4
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab4

T1 Induction proof
T1.1 [2/2/*] Write induction proof           

T2 Big-O notation
T2.1 [2/2/*] Prove Big-O statements          

T3 Build tool for complex C programs
T3.1 [0/0/*] Build all by one command        
T3.2 [0/0/*] Build incrementally             
T3.3 [1/1/*] Build static library            
T3.4 [2/2/*] Build using make                

T4 Sorting algorithms and analysis
T4.1 [2/2/*] Read and test sorting examples  
T4.2 [1/1/*] Merge sorting complexity proof  

A4

Q1 [12/12/*] Sorting algorithms

Q2 [18/18/*] Record data processing

Total: [40/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  



/**
*  _____         _      _____    ___        _               _     
* |_   _|_ _ ___| | __ |___ /   / _ \ _   _| |_ _ __  _   _| |_ _ 
*   | |/ _` / __| |/ /   |_ \  | | | | | | | __| '_ \| | | | __(_)
*   | | (_| \__ \   <   ___) | | |_| | |_| | |_| |_| | |_| | |_ _ 
*   |_|\__,_|___/_|\_\ |____/   \___/ \__,_|\__| .__/ \__,_|\__(_)
*                                              |_|                
*/




1+2i
3+4i
4+6i
-2-2i
-5+10i






/**
*   ____ _           _ _                              _____                  _ 
*  / ___| |__   __ _| | | ___ _ __   __ _  ___  ___  |  ___|_ _  ___ ___  __| |
* | |   | '_ \ / _` | | |/ _ \ '_ \ / _` |/ _ \/ __| | |_ / _` |/ __/ _ \/ _` |
* | |___| | | | |_| | | |  __/ | | | |_| |  __/\__ \ |  _| |_| | |_|  __/ |_| |
*  \____|_| |_|\__,_|_|_|\___|_| |_|\__, |\___||___/ |_|  \__,_|\___\___|\__,_|
*                                   |___/                                      
*/

The instructions tells us to name it complex_main.c but then proceeds to use complex_test.c instead (confusing)

The instructions also told us to run make -clean but that got rid of the required .a file to submit, so I just deleted the .exe and .o files myself





/**
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/


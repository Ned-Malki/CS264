/* complex.c */

#include<stdio.h>
#include "complex.h"

void print_complex(COMPLEX x) {
  if (x.real == 0 && x.imaginary == 0) {
    printf("0");
    return;
  }

  if (x.real != 0)
    printf("%d", x.real);

  if (x.imaginary > 0)
    printf("+%di", x.imaginary);
  else if (x.imaginary < 0)
    printf("%di", x.imaginary);
}

COMPLEX add(COMPLEX x, COMPLEX y) {
  COMPLEX result;
  result.real = x.real + y.real;
  result.imaginary = x.imaginary + y.imaginary;
  return result;
}

COMPLEX subtract(COMPLEX x, COMPLEX y) {
  COMPLEX result;
  result.real = x.real - y.real;
  result.imaginary = x.imaginary - y.imaginary;
  return result;
}

COMPLEX multiply(COMPLEX x, COMPLEX y) {
  COMPLEX result;
  result.real = x.real * y.real - x.imaginary * y.imaginary;
  result.imaginary = x.real * y.imaginary + x.imaginary * y.real;
  return result;
}

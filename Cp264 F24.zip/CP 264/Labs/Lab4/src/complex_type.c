/*
* complex_type.c
* HBF
*/

#include<stdio.h>

typedef struct {
  int real;
  int imaginary;
} COMPLEX;
void print_complex(COMPLEX x);          //output: x.real + x.imaginary i
COMPLEX add(COMPLEX x, COMPLEX y);      //return x+y 
COMPLEX subtract(COMPLEX x, COMPLEX y); //return x-y 
COMPLEX multiply(COMPLEX x, COMPLEX y); //return x*y

void print_complex(COMPLEX x) {
  if (x.real==0 && x.imaginary==0) {
	printf("0");
	return;
  }
  
  if (x.real!=0)
	printf("%d", x.real);

  if (x.imaginary>0)
    printf("+%di", x.imaginary);
  else if (x.imaginary<0)
	printf("%di", x.imaginary);  
}
COMPLEX add(COMPLEX x, COMPLEX y) {
  COMPLEX result;
  result.real = x.real + y.real;
  result.imaginary = x.imaginary + y.imaginary;
  return result;
}
COMPLEX subtract(COMPLEX x, COMPLEX y) {
  COMPLEX result;
  result.real = x.real - y.real;
  result.imaginary = x.imaginary - y.imaginary;
  return result;
}
COMPLEX multiply(COMPLEX x, COMPLEX y) {
  COMPLEX result;
  result.real = x.real*y.real - x.imaginary * y.imaginary;
  result.imaginary = x.real*y.imaginary + x.imaginary * y.real;
  return result;
}

int main() {
  COMPLEX c[2] = {{1, 2},{3, 4}};
  print_complex(c[0]);
  printf("\n");
  print_complex(c[1]);
  printf("\n");
  print_complex(add(c[0], c[1]));
  printf("\n");
  print_complex(subtract(c[0], c[1]));
  printf("\n");
  print_complex(multiply(c[0], c[1]));
  printf("\n");
  return 0;
}


/*
1+2i
3+4i
4+6i
-2-2i
-5+10i
*/



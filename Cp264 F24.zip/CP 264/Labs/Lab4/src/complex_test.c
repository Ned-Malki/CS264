/* main.c */

#include<stdio.h>
#include "complex.h"

int main() {
  COMPLEX c[2] = {{1, 2}, {3, 4}};
  
  print_complex(c[0]);
  printf("\n");

  print_complex(c[1]);
  printf("\n");

  print_complex(add(c[0], c[1]));
  printf("\n");

  print_complex(subtract(c[0], c[1]));
  printf("\n");

  print_complex(multiply(c[0], c[1]));
  printf("\n");

  return 0;
}

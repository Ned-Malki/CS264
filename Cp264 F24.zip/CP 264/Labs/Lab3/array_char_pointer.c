/* 
* Code example for CP264 Data Structures II
* array of char pointers
* HBF 
*/

#include<stdio.h>

int main()
{
  char *array_char[] = {"abc", "cde"};
  int i;
  for (i=0; i<2; i++)
    printf("%s\n", array_char[i]);
  return 0;
}

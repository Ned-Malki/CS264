/* 
* Code example for CP264 Data Structures II
* simple file read: fopen(), fclose(), fgetc()
* HBF 
*/
#include <stdio.h>

int main()
{
  int c;
  FILE *fp = fopen("test.txt", "r");
  if (fp == NULL) {
    perror("Error reading file");
    return 0;
  }

  while((c = fgetc(fp)) != EOF) {
    putchar(c);
  }

  fclose(fp);
  return 0;
}

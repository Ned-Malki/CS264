/* 
* Code example for CP264 Data Structures II
* Formated file writing using fprintf()
* HBF 
*/
#include <stdio.h>
int main() {
  FILE *fp = fopen("test.txt", "w"); 
  if (fp == NULL) {
    perror("Error reading file");
    return 0;
  } 
  int x = 10;
  fprintf(fp, "Hello\n");        //write text to the file
  fprintf(fp, "int x=%d\n", x);  //formatted writing 
  fclose(fp);   			    
  return 0;
}

/* 
 * Code example for CP264 Data Structures II
 * Array of structures
 * HBF 
 */

#include <stdio.h>
#include <string.h>

typedef struct {
	int month;
	int day;
	int year;
} date;

typedef struct {
	long int id;
	char name[20];
	char gender;
	int age;
	date rday;
	date *sday;
	char address[40];
} student;

void display0(student);
void display1(student*);
void display_all(student*, int);

int main() {
	int count = 2;
	student s[count];
	s[0].id = 54321;
	strcpy(s[0].name, "John");
	s[0].gender = 'M';
	s[0].rday.month = 1;
	s[0].rday.day = 1;
	s[0].rday.year = 2017;
	s[0].sday = &s[0].rday;

	s[1] = s[0];
	s[1].id = 12345;
	strcpy(s[1].name, "Peter");

	display0(s[0]);

	student *p = &s[0];
	display1(p);

	display_all(s, count);
	return 0;
}

void display0(student p) {
	// Use %ld for long int
	printf("ID:%ld\nName:%s\nstart day: %d/%d/%d\n\n", p.id, p.name,
			p.sday->month, p.sday->day, p.sday->year);
}

void display1(student *p) {
	// Use %ld for long int
	printf("ID:%ld\nName:%s\nstart day: %d/%d/%d\n\n", p->id, p->name,
			p->sday->month, p->sday->day, p->sday->year);
}

void display_all(student *p, int n) {
	int i;
	for (i = 0; i < n; i++) {
		// Use %ld for long int
		printf("ID:%ld\nName:%s\nstart day: %d/%d/%d\n\n", (p + i)->id,
				(p + i)->name, (p + i)->sday->month, (p + i)->sday->day,
				(p + i)->sday->year);
	}
}

/*
 ID:54321
 Name:John
 start day: 1/1/2017

 ID:54321
 Name:John
 start day: 1/1/2017

 ID:54321
 Name:John
 start day: 1/1/2017

 ID:12345
 Name:Peter
 start day: 1/1/2017
 */


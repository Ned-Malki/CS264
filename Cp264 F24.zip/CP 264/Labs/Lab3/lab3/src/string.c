/* 
 * Code example for CP264 Data Structures II
 * String, pointers, and array of strings
 * HBF 
 */

#include <stdio.h>
#include <string.h>

int main() // Added 'int' type for main
{
	char name[] = "cp264";
	printf("\nsizeof(name)=%lu\n", sizeof(name));  // Use %lu for unsigned long
	printf("%s\n", name);

	char name1[] = { 'c', 'p', '2', '6', '4', '\0' };
	printf("\nsizeof(name1)=%lu\n", sizeof(name1)); // Use %lu
	printf("%s\n", name1);

	char name2[20]; // name holds a string of 19 characters. 
	printf("\nsizeof(name2)=%lu\n", sizeof(name2)); // Use %lu
	name2[0] = 'c';
	name2[1] = 'p';
	name2[2] = '2';
	name2[3] = '6';
	name2[4] = '4';
	name2[5] = '\0';
	printf("%s\n", name2);

	char name3[20] = "cp264";
	printf("\nsizeof(name3)=%lu\n", sizeof(name3)); // Use %lu
	printf("%s\n", name3);

	char name4[20] = { 'c', 'p', '2', '6', '4', '\0' };
	printf("\nsizeof(name4)=%lu\n", sizeof(name4)); // Use %lu
	printf("%s\n", name4);

	char *p;
	p = &name[0]; // p = name;
	printf("%c\n", *p);
	printf("%c\n", *(p + 1));
	printf("%s\n", p + 2);

	char *p1 = "cp264";
	printf("%s\n", p1);
	// *(p1+2) = 'a'; this would cause a runtime error
	printf("%c\n", *(p1 + 2));

	char str[] = "Oxford";
	char *pstr = str;
	printf("\nThe string is: ");
	while (*pstr != '\0') {
		printf("%c", *pstr);
		pstr++;
	}

	char name5[5][40] =
			{ "Data structure II", "C programming language", "cp264" };
	printf("\nsizeof(name5)=%lu", sizeof(name5)); // Use %lu
	printf("\n%s", name5[2]);
	printf("\n%s", name5[0]);
	printf("\n%s", name5[1]);
	*(name5[1] + 2) = 'A';
	printf("\n%c", *(name5[1] + 2));

	char *name6[] = { "Data structure II", "C programming language", "cp264" };
	printf("\nsizeof(name6)=%lu", sizeof(name6)); // Use %lu
	printf("\n%s", name6[2]);
	printf("\n%s", name6[0]);
	printf("\n%s", name6[1]);

	// *(name6[1]+2)  =  'A'; this would cause a runtime error
	printf("\n%c", *(name6[1] + 2));

	return 0;
}

/*
 sizeof(name)=6
 cp264

 sizeof(name1)=6
 cp264

 sizeof(name2)=20
 cp264

 sizeof(name3)=20
 cp264

 sizeof(name4)=20
 cp264
 c
 p
 264
 cp264
 2

 The string is: Oxford
 sizeof(name5)=200
 cp264
 Data strucure II
 C programming language
 A
 sizeof(name6)=12
 cp264
 Data strucure II
 C programming language
 p
 */
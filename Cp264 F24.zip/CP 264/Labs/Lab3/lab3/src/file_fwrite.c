/* 
* Code example for CP264 Data Structures II
* Write to file using fwrite()
* HBF 
*/
#include <stdio.h>
#include <string.h>

int main() {
  char *filename = "test.txt";
  char buf[] = "just write something.";
  
  
  FILE *fp = fopen(filename, "w");
  if (fp == NULL) {
	perror("Error reading file");
	return 0;
  }
  
  fwrite(buf, strlen(buf), 1, fp);
  fclose(fp);
  
  printf("\nfile write done\n");

  return 0;
}



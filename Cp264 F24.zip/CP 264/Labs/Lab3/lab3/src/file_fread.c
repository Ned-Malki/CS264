/* 
* Code example for CP264 Data Structures II
* fwrite(), fread() and fseek()
* HBF 
*/
#include <stdio.h>
#include <string.h>
int main()
{
  char c[] = "this is a testing for using fwrite(), fread() and fseek()";
  char buf[100];
  FILE *fp;
  fp = fopen("test.txt", "w+");
  if (fp == NULL) {
	perror("Error reading file");
	return 0;
  }
  fwrite(c, strlen(c) + 1, 1, fp);  
  fseek(fp, SEEK_SET, 0);  // seek to the beginning of the file
  fread(buf, strlen(c)+1, 1, fp);
  printf("%s\n", buf);
  fclose(fp);
  return 0;
}

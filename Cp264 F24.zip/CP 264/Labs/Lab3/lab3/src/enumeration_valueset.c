/* 
* Code example for CP264 Data Structures II
* enumeration with specific value association
* HBF 
*/

#include <stdio.h>

enum mweekdays {
  mSunday,
  mMonday = 2,
  mTuesday,
  mWednesday,
  mThursday = 6,
  mFriday,
  mSaturday
};

typedef enum mweekdays mDAYTYPE;

int main()
{
  printf("Enumeration with default values\n");
  printf("Sun %d\n",  mSunday);
  printf("Monday %d\n", mMonday);
  printf("Tuesday %d\n", mTuesday);
  printf("Wednesday %d\n", mWednesday);
  printf("Thursday %d\n", mThursday);
  printf("Friday %d\n", mFriday);
  printf("Saturday %d\n", mSaturday);
  
  mDAYTYPE d = mWednesday;
  printf("This is %d\n", d);
  mDAYTYPE n = d+1;
  printf("increase %d\n", n);

  return 0;
}

/*
Enumeration with default values
Sun 0
Monday 2
Tuesday 3
Wednesday 4
Thursday 6
Friday 7
Saturday 8
This is 4
increase 5
*/
/* 
 * Code example for CP264 Data Structures II
 * return structure
 * HBF 
 */

#include <stdio.h>

typedef struct {
	int x;
	int y;
} POINT;

POINT point_inc(POINT p) {
	p.x = p.x + 1;
	p.y = p.y + 1;
	return p;
}

void display(POINT p) {
	printf("%d,%d\n", p.x, p.y);
}

int main() {  // Changed 'void' to 'int'
	POINT p1 = { 2, 3 };
	display(p1);
	POINT p2 = point_inc(p1);
	display(p2);

	return 0;  // Return 0 indicating successful execution
}

/*
 2,3
 3,4
 */


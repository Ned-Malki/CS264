/* 
* Code example for CP264 Data Structures II
* use enumeration
* HBF 
*/
#include <stdio.h>

typedef enum weekdays {
  Sunday,
  Monday,
  Tuesday,
  Wednesday,
  Thursday,
  Friday,
  Saturday
} DAYTYPE;

void display_day(DAYTYPE day){
  switch(day){
    case Sunday: printf("Sunday"); break;
    case Monday: printf("Monday"); break;
    case Tuesday: printf("Tuesday"); break;
    case Wednesday: printf("Wednesday"); break;
    case Thursday: printf("Thursday"); break;
    case Friday: printf("Friday"); break;
    case Saturday: printf("Saturday"); break;
  }
}

int main()
{

  int i = 0;
  for (i = 1; i<=7; i++) {
	 printf("\nThe %ith week day is ", i);
     display_day(i);	 
  } 	  
  
  DAYTYPE today = Tuesday;
  printf("\nToday is ");
  display_day(today);
  printf("\nTomorrow is ");
  display_day(today+1);	  
  
  if(today == Sunday || today == Saturday)
    printf("\nToday is weekend\n");
  else
    printf("\nToday is a work day\n");
  
  return 0;
}


/*
The 1th week day is Monday
The 2th week day is Tuesday
The 3th week day is Wednesday
The 4th week day is Thursday
The 5th week day is Friday
The 6th week day is Saturday
The 7th week day is
Today is Tuesday
Tomorrow is Wednesday
Today is a work day
*/




/*
 * Code example for CP264 Data Structures II
 * Testing structure
 * HBF
 */

#include <stdio.h>
#include <stdint.h>  // For uintptr_t

int main() {
	typedef struct {
		int id;
		char name[20];
		char gender;
		char address[40];
	} student;

	student s = { 12345, "John", 'M', "123 Bricker Rd" };
	student s1;

	student *pt = &s;

	printf("ID: %d\nname: %s\nGender: %c\naddress: %s\n", s.id, s.name,
			s.gender, s.address);
	printf("ID: %d\nname: %s\nGender: %c\naddress: %s\n", pt->id, pt->name,
			pt->gender, pt->address);
	printf("ID: %d\nname: %s\nGender: %c\naddress: %s\n", (*pt).id, (*pt).name,
			(*pt).gender, (*pt).address);

	// Use uintptr_t to safely cast pointer to an integer type and calculate relative addresses
	uintptr_t base_addr = (uintptr_t) &s; // Use base address of the first element for relative calculations

	printf("Address of s.id: %lu\n", (uintptr_t) &s.id - base_addr);
	printf("Address of s.name: %lu\n", (uintptr_t) &s.name - base_addr);
	printf("Address of s.gender: %lu\n", (uintptr_t) &s.gender - base_addr);

	s1 = s; // Assign s to s1

	uintptr_t base_addr_s1 = (uintptr_t) &s1; // New base address for s1

	printf("Address of s1.id: %lu\n", (uintptr_t) &s1.id - base_addr_s1);
	printf("Address of s1.name: %lu\n", (uintptr_t) &s1.name - base_addr_s1);
	printf("Address of s1.gender: %lu\n",
			(uintptr_t) &s1.gender - base_addr_s1);

	return 0;
}

/*
 ID: 12345
 name:John
 Gender:M
 address: 123 Bricker Rd
 ID: 12345
 name:John
 Gender:M
 address: 123 Bricker Rd
 ID: 12345
 name:John
 Gender:M
 address: 123 Bricker Rd
 Address of s.id: 6422216
 Address of s.name: 6422220
 Address of s.gender: 6422240
 Address of s1.id: 6422148
 Address of s1.name: 6422152
 Address of s1.gender: 6422172
 */

/* 
* Code example for CP264 Data Structures II
* Write binary file
* HBF 
*/
#include<stdio.h>

struct record
{
  int id;
  char name[20];
  float mark;
};

int main()
{
  struct record x;
  int n,i;
  FILE *fp = fopen("record.bin","wb");
  printf("How many records?");
  scanf("%d",&n);
  printf("Enter %d records:\n",n);
 
  for(i=1;i<=n;i++)
  {
    printf("ID:");
    scanf("%d", &x.id);
    printf("Name:");
    scanf("%s", x.name);
    printf("Mark:");
    scanf("%f", &x.mark);
    fwrite(&x, sizeof(x), 1, fp);
  }
 
  fclose(fp);
  return 0;
}
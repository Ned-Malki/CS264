/* 
* Code example for CP264 Data Structures II
* Read binary file
* HBF 
*/
#include<stdio.h>

struct record
{
  int id;
  char name[20];
  float mark;
};

int main() {
 struct record x;
 int len = 0;
 
 FILE *fp=fopen("record.bin","rb");
 if (fp == NULL) {
   perror("Error opening file");
   return 0;
 }
 
 printf("Records:\n");
 while(!feof(fp)) {
  if (fread(&x, sizeof(x), 1, fp)>0)  // fread return the number of bytes read
    printf("ID:%d\nName:%s\nMark:%3.1f\n",x.id, x.name, x.mark);
 }
 
 fclose(fp);
 return 0;
}
/* 
* Code example for CP264 Data Structures II
* read string from file using fopen(), fclose(), fgets()
* HBF 
*/
#include <stdio.h>

int main(int argc, char *argv[])
{
  char buf[128];
  FILE *fp;
  
  if ( (fp=fopen("test.txt", "r") )  ==  NULL ) {
    printf("Error\n");
    return 0;
  }
  
  while( !feof(fp) ) {
    if( fgets(buf, sizeof(buf), fp) ) {
      printf("%s", buf);
	}
  }
  
  fclose(fp);
  return 0;
}

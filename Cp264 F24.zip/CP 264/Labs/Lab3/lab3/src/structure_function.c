/* 
 * Code example for CP264 Data Structures II
 * String, pointers, and array of strings
 * HBF 
 */
#include <stdio.h>

struct arraywrapper {
	int arr[10];
};

void test(struct arraywrapper x) {
	int i;
	for (i = 0; i < 10; i++) {
		x.arr[i] = i;
	}

	for (i = 0; i < 10; i++) {
		printf("%d ", x.arr[i]);
	}
	// Corrected format specifier to %lu
	printf("\nsize %lu", sizeof(x));
}

void test1(struct arraywrapper *x) {
	int i;
	for (i = 0; i < 10; i++) {
		x->arr[i] = i;
	}

	for (i = 0; i < 10; i++) {
		printf("%d ", x->arr[i]);
	}
}

void test2(struct arraywrapper x[], int n) {
	int i, j;
	for (j = 0; j < n; j++) {
		for (i = 0; i < 10; i++) {
			x[j].arr[i] = i;
		}
	}
}

// Changed return type of main to int
int main() {
	struct arraywrapper a = { 0 };  // Initialize to 0
	printf("data in array wrapper\n");
	int i;
	for (i = 0; i < 10; i++) {
		a.arr[i] = 0;
	}
	test(a);
	printf("\ndata in array wrapper after function call\n");
	for (i = 0; i < 10; i++) {
		printf("%d ", a.arr[i]);
	}
	printf("\n");

	test1(&a);
	printf("\ndata in array wrapper after function call of reference pass\n");
	for (i = 0; i < 10; i++) {
		printf("%d ", a.arr[i]);
	}

	int m = 2;
	struct arraywrapper y[m];
	int j;
	for (j = 0; j < m; j++) {
		for (i = 0; i < 10; i++) {
			y[j].arr[i] = 0;
		}
	}
	printf("\ndata in array of wrapper structure");
	for (j = 0; j < m; j++) {
		printf("\n");
		for (i = 0; i < 10; i++) {
			printf("%d ", y[j].arr[i]);
		}
	}
	test2(y, m);
	printf("\ndata in array of wrapper structure after passing to function");
	for (j = 0; j < m; j++) {
		printf("\n");
		for (i = 0; i < 10; i++) {
			printf("%d ", y[j].arr[i]);
		}
	}
	return 0;
}

/*
 data in array wrapper
 0 1 2 3 4 5 6 7 8 9
 size 40
 data in array wrapper after function call
 0 0 0 0 0 0 0 0 0 0
 0 1 2 3 4 5 6 7 8 9
 data in array wrapper after function call of reference pass
 0 1 2 3 4 5 6 7 8 9
 data in array of wrapper structure
 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0
 data in array of wrapper structure after passing to function
 0 1 2 3 4 5 6 7 8 9
 0 1 2 3 4 5 6 7 8 9
 */

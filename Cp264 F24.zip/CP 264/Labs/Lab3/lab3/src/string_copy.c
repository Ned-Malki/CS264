/* 
* Code example for CP264 Data Structures II
* strcpy, memcpy
* HBF 
*/
#include <stdio.h>
#include <string.h>

int main ()
{
  const char src[50] = "memory copy function";
  char dest[50] = {0};

  printf("Before strcpy\n");
  printf("%s\n", dest);
  strcpy(dest, src);
  printf("\nAfter strcpy\n");
  printf("%s\n\n", dest);  
  
  strcpy(dest, "");
  printf("Before memcpy\n");
  printf("%s\n", dest);
  memcpy(dest, src, strlen(src)+1);
  printf("\nAfter memcpy\n");
  printf("%s\n\n", dest);

  const int a[50] = {1,2, 4};
  int b[50] = {0};
  int i;
  printf("\nBefore memory coping\n");
  for (i = 0; i<3; i++) 
    printf("%d  ", b[i]);
	  
  memcpy((char*) b, (char*) a, 4*3);
  
  printf("\nAfter memory coping\n");
  for (i = 0; i<3; i++) 
	printf("%d  ", b[i]);
	  
  return(0);
}

/*
Before strcpy


After strcpy
memory copy function

Before memcpy


After memcpy
memory copy function


Before memory coping
0  0  0
After memory coping
1  2  4
*/
/* 
* Code example for CP264 Data Structures II
* Use union
* HBF 
*/
#include <stdio.h>
#include <string.h>

typedef union {
  int class;
  char position[10];
} pType;

typedef struct{
  int id;
  char name[20];
  char job;
  pType category;
} recType;

int main() {
  int i; 
  recType person[2];
  person[0].id = 101;
  strcpy(person[0].name, "John");
  person[0].job = 's';
  person[0].category.class = 264;
  
  person[1].id = 102;
  strcpy(person[1].name, "Peter");
  person[1].job = 't';
  strcpy(person[1].category.position, "professor");
  printf("ID     Name        Job    Class/Position\n");
  for (i = 0; i < 2; i++){
    if (person[i].job == 's')
      printf("%-6d %-10s    %-3c  %-6d\n", person[i].id, person[i].name, person[i].job, person[i].category.class );
    else
      printf("%-6d %-10s    %-3c  %s\n", person[i].id,   person[i].name, person[i].job, person[i].category.position);
  }
  return 0;
}

/*
ID     Name        Job    Class/Position
101    John          s    264
102    Peter         t    professor
*/

/* 
* Code example for CP264 Data Structures II
* Reading csv file
* HBF 
*/
#include<stdio.h>
struct record
{
  int id;
  float mark;
};

int main()
{
  struct record x;
  FILE *fp=fopen("record.txt","r");
  if(fp == NULL) return 0;
  printf("Records:\n");
  while(!feof(fp)) {
    fscanf(fp,"%d,%f\n", &x.id, &x.mark);
    printf("\n\nID:%d\nMark:%f",x.id, x.mark);
  }
  fclose(fp);
  return 0;
}
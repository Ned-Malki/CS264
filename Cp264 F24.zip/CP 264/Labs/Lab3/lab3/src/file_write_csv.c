/* 
* Code example for CP264 Data Structures II
* Write csv file
* HBF 
*/
#include<stdio.h>
struct record
{
  int id;
  float mark;
};

int main()
{
  
  FILE *fp;
  struct record x;
  int n,i;
  fp=fopen("record.txt","w");
  if(fp == NULL) return 0;
 
  printf("How many records?");
  scanf("%d",&n);
  printf("Enter %d records:\n",n);
 
  for(i=1;i<=n;i++)
  {
    printf("ID:");
    scanf("%d", &x.id);  
    printf("Mark:");
    scanf("%f", &x.mark);
    fprintf(fp, "%d,%f\n", x.id, x.mark);
  }
  fclose(fp);
  printf("file is closed");
  return 0;
}
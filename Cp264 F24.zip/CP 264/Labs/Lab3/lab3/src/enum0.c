/* class example on enumeration
 * HBF
 */
#include <stdio.h>
#include <string.h>

typedef enum {
	false, true
} BOOLEAN;

int main() {
	printf("size of BOOLEAN:%lu\n", sizeof(BOOLEAN));
	printf("value of false:%d\n", false);
	printf("value of true:%d\n", true);

	BOOLEAN flag = false;
	printf("value of flag.:%d\n", flag);
	flag = true;
	printf("value of flag.:%d\n", flag);
	return 0;
}

/*
 size of BOOLEAN:4
 value of false:0
 value of true:1
 value of flag.:0
 value of flag.:1
 */

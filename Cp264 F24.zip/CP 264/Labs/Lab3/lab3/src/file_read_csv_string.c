/* 
* Code example for CP264 Data Structures II
* Read csv file containing string values
* HBF 
*/

#include<stdio.h>
#include <stdlib.h>
#include<string.h>

struct record
{
  int id;
  char name[20];
  float mark;
};

int main()
{
  struct record x;
  FILE *fp=fopen("record.txt","r");
  if(fp == NULL) return 0;
 
  char line[40]; 
  const char delimiters[2] = ",";
  char *token;
  printf("Record:\n");
 
  while (fgets(line, sizeof(line), fp) != NULL) {
	token = strtok(line, delimiters);
	x.id = atoi(token);
	token = strtok(NULL,delimiters);
	strcpy(x.name, token);
	token = strtok(NULL,delimiters);
	x.mark = atof(token);
    printf("\n\nID:%d\n%s\nMark:%4.2f",x.id, x.name, x.mark);
  }
  fclose(fp);
  return 0;
}

/* 
 * Code example for CP264 Data Structures II
 * test union
 * HBF 
 */
#include <stdio.h>
#include <string.h>

typedef union {
	int id;
	double score;
} RECORD;

void display(RECORD a, int i) {
	if (i == 0)
		printf("%d\n", a.id);
	else
		printf("%f\n", a.score);
}

RECORD inc(RECORD a, int i) {
	if (i == 0)
		a.id += 1;
	else
		a.score += 1;
	return a;
}

int main() {
	// Use %lu for size_t (returned by sizeof())
	printf("sizeof(RECORD):%lu\n", sizeof(RECORD));

	RECORD a;
	// Use %p for pointer addresses
	printf("address_a.:%p\n", (void*) &a);
	printf("address_a.id:%p\n", (void*) &a.id);
	printf("address_a.score:%p\n", (void*) &a.score);

	a.id = 12;
	int rid = a.id;
	printf("%d\n", a.id);      // output: 12  
	printf("%d\n", rid);       // output: 12
	printf("%f\n", a.score);   // not meaningful when interpreted as score

	a.score = 88.34;
	printf("%d\n", a.id);      // not meaningful when interpreted as id
	printf("%f\n", a.score);   // output: 88.340000  
	display(a, 1);

	RECORD b = a;
	display(b, 1);

	RECORD c = inc(b, 1);
	display(c, 1);

	RECORD *p = &a;
	printf("%f\n", p->score);

	return 0;
}

/*
 izeof(RECORD):8
 address_a.:6422272
 address_a.id:6422272
 address_a.score:6422272
 12
 12
 0.000000
 -1889785610
 88.340000
 88.340000
 88.340000
 89.340000
 88.340000
 */

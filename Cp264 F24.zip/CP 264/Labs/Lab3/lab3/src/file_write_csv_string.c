/* 
* Code example for CP264 Data Structures II
* Write csv file containing string values
* HBF 
*/
#include<stdio.h>

struct record
{
  int id;
  char name[20];
  float mark;
};

int main()
{
  FILE *fp;
  struct record x;
  int n,i;
  fp=fopen("record.txt","w");
  if(fp == NULL) return 0;
  printf("How many records?");
  scanf("%d",&n);
  printf("Enter %d records:\n",n);
 
  for(i=0;i<n;i++)
  {
    printf("ID:");
    scanf("%d", &x.id);
    printf("Name:");
    scanf("%s", x.name);
    printf("Mark:");
    scanf("%f", &x.mark);
    fprintf(fp, "%d,%s,%f\n", x.id, x.name, x.mark);
  }
  fclose(fp);
  return 0;
}

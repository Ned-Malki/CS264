/* 
 * Code example for CP264 Data Structures II
 * String comparison function
 * HBF 
 */
#include <stdio.h>
#include <string.h>

// Function declarations
int compare(char s1[], char s2[]);
int comparep(const char *s1, const char *s2);
int strcmp_simple(const char *s1, const char *s2);  // New helper function

int main() {
	char a[100] = "abc";
	char b[100] = "ab";

	printf(
			"use fgets to get a string from keyboard (stop at enter \\n is the last char of the string): ");
	fgets(a, sizeof(a), stdin);
	printf("\n%s", a);
	printf("%lu", strlen(a));  // Corrected %d to %lu for size_t
	a[strlen(a) - 1] = '\0';  // Remove the newline character from fgets
	printf("\n%s", a);
	printf("\n%lu", strlen(a));  // Corrected %d to %lu for size_t

	printf(
			"\nuse scanf to get a string from keyboard (will stop at first space or enter): ");
	scanf("%s", b);
	printf("%s", b);
	printf("\n%lu\n", strlen(b));  // Corrected %d to %lu for size_t

	printf("compare(%s,%s)=%d\n", a, b, compare(a, b));
	printf("compare(%s,%s)=%d\n", b, a, compare(b, a));
	printf("compare(%s,%s)=%d\n", a, a, compare(a, a));

	printf("comparep(%s,%s)=%d\n", a, b, comparep(a, b));
	printf("comparep(%s,%s)=%d\n", b, a, comparep(b, a));
	printf("comparep(%s,%s)=%d\n", a, a, comparep(a, a));

	// Use strcmp_simple to limit output to 1, -1, or 0
	printf("strcmp(%s,%s)=%d\n", a, b, strcmp_simple(a, b));
	printf("strcmp(%s,%s)=%d\n", b, a, strcmp_simple(b, a));
	printf("strcmp(%s,%s)=%d\n", a, a, strcmp_simple(a, a));

	char *s1 = &a[0];
	char *s2 = &b[0];

	printf("compare(%s,%s)=%d\n", s1, s2, compare(s1, s2));
	printf("compare(%s,%s)=%d\n", s2, s1, compare(s2, s1));
	printf("compare(%s,%s)=%d\n", s1, s1, compare(s1, s1));

	printf("comparep(%s,%s)=%d\n", s1, s2, comparep(s1, s2));
	printf("comparep(%s,%s)=%d\n", s2, s1, comparep(s2, s1));
	printf("comparep(%s,%s)=%d\n", s1, s1, comparep(s1, s1));

	// Use strcmp_simple to limit output to 1, -1, or 0
	printf("strcmp(%s,%s)=%d\n", s1, s2, strcmp_simple(s1, s2));
	printf("strcmp(%s,%s)=%d\n", s2, s1, strcmp_simple(s2, s1));
	printf("strcmp(%s,%s)=%d\n", s1, s1, strcmp_simple(s1, s1));

	char *s3 = NULL;
	char *s4 = "ab";

	printf("%d\n", comparep(s3, s4));
	// printf("%d\n", strcmp(s3, s4)); // Run-time error if enabled

	return 0;
}

// Comparison function for arrays of characters
int compare(char s1[], char s2[]) {
	int i = 0;
	while (s1[i] || s2[i]) {
		if (s1[i] < s2[i])
			return -1;
		else if (s1[i] > s2[i])
			return 1;
		else {
			i++;
		}
	}
	return 0;
}

// Comparison function for pointers to characters
int comparep(const char *s1, const char *s2) {
	if (s1 == NULL || s2 == NULL)
		return -2;
	while (*s1 || *s2) {
		if (*s1 < *s2)
			return -1;
		else if (*s1 > *s2)
			return 1;
		else {
			s1++;
			s2++;
		}
	}
	return 0;
}

// Helper function to normalize strcmp output
int strcmp_simple(const char *s1, const char *s2) {
	int result = strcmp(s1, s2);
	if (result > 0)
		return 1;
	else if (result < 0)
		return -1;
	else
		return 0;
}

/*
 compare(abc,ab)=1
 compare(ab,abc)=-1
 compare(abc,abc)=0
 comparep(abc,ab)=1
 comparep(ab,abc)=-1
 comparep(abc,abc)=0
 strcmp(abc,ab)=1
 strcmp(ab,abc)=-1
 strcmp(abc,abc)=0
 compare(abc,ab)=1
 compare(ab,abc)=-1
 compare(abc,abc)=0
 comparep(abc,ab)=1
 comparep(ab,abc)=-1
 comparep(abc,abc)=0
 strcmp(abc,ab)=1
 strcmp(ab,abc)=-1
 strcmp(abc,abc)=0
 -2
 */
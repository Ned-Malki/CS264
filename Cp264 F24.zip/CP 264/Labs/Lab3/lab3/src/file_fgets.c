/* 
* Code example for CP264 Data Structures II
* read string from file using fgets()
* HBF 
*/
#include <stdio.h>

int main() 
{
  char buf[100];
  
  FILE *fp = fopen("test.txt", "r");
  if (fp == NULL) {
    perror("Error");
	return 0;
  }

  fgets(buf, sizeof(buf), fp); // get first line
  puts(buf);                   // put to stdout  
  fclose(fp);

  return 0;
}

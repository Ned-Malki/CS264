/* 
* Code example for CP264 Data Structures II
* String, pointers, and array of strings
* HBF 
*/

#include <stdio.h>
#include<stdio.h>
#include<string.h>
 
main()
{
  char name[] = "cp264";
  printf("\nsizeof(name)=%d\n", sizeof(name));
  printf("%s\n", name);

  char name1[] = {'c', 'p', '2', '6', '4', '\0'}; 
  printf("\nsizeof(name1)=%d\n", sizeof(name1));
  printf("%s\n", name1);

  char name2[20];//name hold a string of 19 characters. 
  printf("\nsizeof(name2)=%d\n", sizeof(name2));
  name2[0] = 'c';      // name[0] = 99; 
  name2[1] = 'p';
  name2[2] = '2';
  name2[3] = '6';
  name2[4] = '4';
  name2[5] = '\0';    // name[5] = 0;    
  printf("%s\n", name2);

  char name3[20] = "cp264";
  printf("\nsizeof(name3)=%d\n", sizeof(name3));     
  printf("%s\n", name3);

  char name4[20] = {'c', 'p', '2', '6', '4', '\0'}; 
  printf("\nsizeof(name4)=%d\n", sizeof(name4));
  printf("%s\n", name4);
  char *p;
  p = &name[0]; //p = name;
  printf("%c\n", *p);
  printf("%c\n", *(p+1));
  printf("%s\n", p+2);

  char *p1 = "cp264";
  printf("%s\n", p1);
  
  // *(p1+2) = 'a'; this is a run time error
  printf("%c\n", *(p1+2));
 
  char str[] = "Oxford";
  char *pstr = str;
  printf("\nThe string is: ");
  while(*pstr != '\0')
  {  
    printf("%c", *pstr);
    pstr++;
  }

  char name5[5][40] = {"Data strucure II", "C programming language", "cp264"};
  printf("\nsizeof(name5)=%d", sizeof(name5));
  printf("\n%s", name5[2]);
  printf("\n%s", name5[0]);
  printf("\n%s", name5[1]);
  *(name5[1]+2)  =  'A';
  printf("\n%c", *(name5[1]+2));
  
  char *name6[] = {"Data strucure II", "C programming language", "cp264"};
  printf("\nsizeof(name6)=%d", sizeof(name6));
  printf("\n%s", name6[2]);
  printf("\n%s", name6[0]);
  printf("\n%s", name6[1]);
  
  //*(name6[1]+2)  =  'A';  this is a run time error
  printf("\n%c", *(name6[1]+2));
  
  return 0;
}

/*
sizeof(name)=6
cp264

sizeof(name1)=6
cp264

sizeof(name2)=20
cp264

sizeof(name3)=20
cp264

sizeof(name4)=20
cp264
c
p
264
cp264
2

The string is: Oxford
sizeof(name5)=200
cp264
Data strucure II
C programming language
A
sizeof(name6)=12
cp264
Data strucure II
C programming language
p
*/7
/* 
* Code example for CP264 Data Structures II
* Pass array to functions
* HBF 
*/

#include<stdio.h>
void inc(int[]);

int main( void ) 
{
  int i, x[3];
  for( i = 0; i < 3; i++)
    x[i] = i;
  printf("Before increase\n"); 
  for( i = 0; i < 3; i++ )
	printf("x[%i]: %i\n", i, x[i]); 
  
  inc(x); 
  printf("After increase\n"); 
  for( i = 0; i < 3; i++ )
	printf("x[%i]: %i\n", i, x[i]); 
  return 0;
}  

void inc(int a[]) {
  int i;
  for(i = 0; i < 3; i++ ) 
	a[i]++;
}

/*
Before increase
x[0]: 0
x[1]: 1
x[2]: 2
After increase
x[0]: 1
x[1]: 2
x[2]: 3
*/
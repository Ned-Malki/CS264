/* 
* Code example for CP264 Data Structures II
* Global array and local array
* HBF 
*/
#include <stdio.h>
#define SIZE 5
int list[SIZE];    // global array
int main(){
  int a[SIZE]; // local array 	
  int i; 
  printf("Global array\n");  
  for (i=0;i < SIZE; i++ )  {    
    list[i] = i + 1;    
    printf("list[%d]: %d, address: %lu\n", i, list[i], &list[i]);  
  }
  printf("Local array\n");    
  for (i=0; i < SIZE; i++ )  {    
    a[i] = SIZE  - i;    
    printf("a[%d]: %d, address: %lu\n", i, a[i], &a[i]);  
  }  
  return 0;
}
/*
Global array
list[0]: 1, address: 4219876
list[1]: 2, address: 4219880
list[2]: 3, address: 4219884
list[3]: 4, address: 4219888
list[4]: 5, address: 4219892
Local array
a[0]: 5, address: 6684296
a[1]: 4, address: 6684300
a[2]: 3, address: 6684304
a[3]: 2, address: 6684308
a[4]: 1, address: 6684312
*/

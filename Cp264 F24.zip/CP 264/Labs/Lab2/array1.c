/* 
* Code example for CP264 Data Structures II
* Array access by pointer 
* HBF 
*/
#include <stdio.h>
#define SIZE 5
int main(){  
  int list[ SIZE ];   /* array of int's as local variables*/ 
  int i;
  int *p = &list[0];
  for (i=0;i < SIZE; i++ )  {    
    list[ i ] = i + 1;
    printf("list[%d]: %d, address: %lu\n", i, *(p+i), p+i);  
  }

  char c[ SIZE ]; 
  char *cp = &c[0];
  for (i=0;i < SIZE; i++ )  {    
    c[ i ] = 'a' + i;     
	printf("c[%d]: %c, address: %lu\n", i, *(cp+i), cp+i);  
  }
   
  double d[ SIZE ]; 
  double *dp = d;
  for (i=0;i < SIZE; i++ )  {    
    d[ i ] = i + 1;
    printf("d[%d]: %f, address: %lu\n", i, *(dp+i), dp+i);  
  }
  return 0;
}

/*
list[0]: 1, address: 6684284
list[1]: 2, address: 6684288
list[2]: 3, address: 6684292
list[3]: 4, address: 6684296
list[4]: 5, address: 6684300
c[0]: a, address: 6684279
c[1]: b, address: 6684280
c[2]: c, address: 6684281
c[3]: d, address: 6684282
c[4]: e, address: 6684283
d[0]: 1.000000, address: 6684232
d[1]: 2.000000, address: 6684240
d[2]: 3.000000, address: 6684248
d[3]: 4.000000, address: 6684256
d[4]: 5.000000, address: 6684264
*/
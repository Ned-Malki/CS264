/*
 * Code for CP264 Data Structures II
 * Testing void pointers and addresses
 * HBF
 */
#include <stdio.h>

int a = 1;
int b = 2;

int main() {
  static int c = 3;

  int x = 10;
  double y = 1.1;
  int *p = &x;
  double *py = &y;

  printf("Value of a: %d, address: %p\n", a, (void *) &a);
  printf("Value of b: %d, address: %p\n", b, (void *) &b);
  printf("Value of c: %d, address: %p\n", c, (void *) &c);
  printf("Value of x: %d, address: %p\n", x, (void *) &x);
  printf("Value of y: %f, address: %p\n", y, (void *) &y);

  printf("Value in pointer variable p: %p, sizeof p: %zu, address of p: %p\n", 
         (void *) p, sizeof(p), (void *) &p);
  printf("Value in py: %p, sizeof py: %zu\n", (void *) py, sizeof(py));

  void *ptr;
  ptr = &x;
  printf("void pointer address: %p, casted value: %d\n", ptr, *(int *) ptr);

  return 0;
}

/*
Value of a: 1, address: 4206600 
Value of b: 2, address: 4206604
Value of c: 3, address: 4206608
Value of x: 10, address: 6684308
Value of y: 1.100000, address: 6684296
Value in pointer variable p, 6684308, sizeof p: 4, address of p:  6684292
Value in py: 6684296, sizeof py: 4
void pointer address: 6684308, casted value: 10
*/
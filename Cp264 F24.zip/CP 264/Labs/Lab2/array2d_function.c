/* 
* Code example for CP264 Data Structures II
* 2D array and function
* HBF 
*/

#include<stdio.h>

void display(int row, int col, int arr[row][col]) {
  int i, j;
  for(i=0; i<row; i++) {
    for(j=0;j<col;j++) {
	  printf("%d ", arr[i][j]);
    }     
    printf("\n");  
  } 
}

void display1(int row, int col, int arr[][col]) {
  int i, j;
  for(i=0; i<row; i++) {
    for(j=0;j<col;j++) {
	  printf("%d ", arr[i][j]);
    }     
    printf("\n");  
  } 
}

void display2(int row, int col, int *m) {
  int i, j;
  int (*a)[col] = (int (*)[col]) m;  // Cast m to a pointer to a 2D array
  for (i = 0; i < row; i++) {
    for (j = 0; j < col; j++) {
      printf("%d ", a[i][j]);
    }
    printf("\n");
  }
}


void transpose(int n, int m[n][n]) {   // need declare n first
  int i = 0, j = 0, temp;
 
  for (i = 0; i < n; i++) {
    for (j = i + 1; j < n; j++) {
      temp = m[i][j]; 
      m[i][j] = m[j][i];
      m[j][i] = temp;
    }
  }
}

void transpose_pointer(int n, int *m) {
  int *p = m, i = 0, j = 0, temp;
  for (i = 0; i < n; i++){
    for (j = i + 1; j < n; j++) { // Swap of m[i][j] and m[j][i]
      temp = *(p + i*n + j);     
      *(p + i*n + j) = *(p + j*n + i);
      *(p + j*n + i) = temp;
    }
  }
}

int main() {
  printf("======arr[2][3]======\n");
  int arr[2][3] = {{1,2,3}, {4,5,6}};

  printf("display()\n");
  display(2, 3, arr);
   printf("display1()\n");
  display1(2, 3, arr);
   
  
  int *m = &arr[0][0]; 
  int (*a)[3];
  a = arr; //&arr[0];
  printf("*(*(a + 0) + 0):%d\n", *(*(a + 0) + 0));
  printf("*(*a + 2):%d\n", *(*a + 2));
  printf("*(a[0] + 2):%d\n", *(a[0] + 2));
  
  printf("display2()\n");
  display2(2, 3, m);
 
  printf("======arr[3][3]======\n");
  
  printf("\n");  
  int mat[3][3] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
  int *p = &mat[0][0];
  display(3, 3, mat);
  printf("\n"); 
  printf("======transpose(3, mat)======\n");
  transpose(3, mat);
  display(3, 3, mat); 
  printf("\n");  
  printf("======transpose_pointer(3, &mat[0][0])======\n");
  transpose_pointer(3, &mat[0][0]);
  display(3, 3, mat);
  return 0;
}

/*

======arr[2][3]======
display()
1 2 3
4 5 6
display1()
1 2 3
4 5 6
*(*(a + 0) + 0):1
*(*a + 2):3
*(a[0] + 2):3
display2()
1 2 3
4 5 6
======arr[3][3]======

1 2 3
4 5 6
7 8 9

======transpose(3, mat)======
1 4 7
2 5 8
3 6 9

======transpose_pointer(3, &mat[0][0])======
1 2 3
4 5 6
7 8 9
*/
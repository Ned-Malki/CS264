/* 
* Code example for CP264 Data Structures II
* testing concepts of pointers
* HBF 
*/

#include<stdio.h>
int main() {
  int x = 10;
  int *ptr;
  ptr = &x;
  printf("Value of x: %d\n", x);
  printf("Address of x: %lu\n",  &x);
  printf("Value of pointer ptr: %lu\n", ptr);
  printf("Address of pointer ptr: %lu\n", &ptr);
  printf("ptr pointing to value: %d\n",*ptr);
  return 0;
}

/*
Value of x: 10
Address of x: 6684316
Value of pointer ptr: 6684316
Address of pointer ptr: 6684312
ptr pointing to value: 10
*/

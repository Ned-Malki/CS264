/*
* Code example for CP264 Data Structures II
* 2D array and 3D array
* Write a program to display Pascal's triangle, i.e. the coefficients of (1+x)^n, n = 0, 1, 2, ..., m 
* HBF 
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* args[])
{
  int n = 5;
  if (argc > 1) n = atoi(args[1]);

  // Initialize the Pascal's triangle array
  int a[n][n];
  
  int i, j;
  // Set all values in the array to 0
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      a[i][j] = 0;
    }
  }
  
  // Base case for Pascal's triangle
  a[0][0] = 1;

  // Fill Pascal's triangle
  for (i = 1; i < n; i++) {
    a[i][0] = 1;  // First element in each row is 1
    for (j = 1; j <= i; j++) {
      a[i][j] = a[i-1][j-1] + a[i-1][j];  // Compute the coefficients
    }
  }

  // Print Pascal's triangle
  printf("Pascal's Triangle:\n");
  for (i = 0; i < n; i++) {
    printf("\n");
    for (j = 0; j <= i; j++) {
      printf("%d ", a[i][j]);  
    }
  }
  printf("\n");

  // Print memory addresses of Pascal's triangle
  printf("Memory addresses of Pascal's triangle elements:\n");
  for (i = 0; i < n; i++) {
    printf("\n");
    for (j = 0; j <= i; j++) {
      printf("%p ", (void *)&a[i][j]);
    }
  }
  printf("\n");

  // Example 3D array and pointer handling
  int arr[2][3][4] = {
    { {1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12} },
    { {13, 14, 15, 16}, {0, 0, 0, 0}, {0, 0, 0, 0} }
  };
  int (*parr)[3][4] = arr;

  printf("\n3D Array Values and Addresses:\n");
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++) {
      printf("\n");
      for (int k = 0; k < 4; k++) {
        printf("%2d (%p)  ", arr[i][j][k], (void *)&arr[i][j][k]);
      }
    }
  }
  
  return 0;
}


/*
  1
  1  1
  1  2  1
  1  3  3  1
  1  4  6  4  1

  6421952  6421956  6421960  6421964  6421968
  6421972  6421976  6421980  6421984  6421988
  6421992  6421996  6422000  6422004  6422008
  6422012  6422016  6422020  6422024  6422028
  6422032  6422036  6422040  6422044  6422048

  6421952  6421956  6421960  6421964  6421968
  6421972  6421976  6421980  6421984  6421988
  6421992  6421996  6422000  6422004  6422008
  6422012  6422016  6422020  6422024  6422028
  6422032  6422036  6422040  6422044  6422048

  6421952  6421972  6421992  6422012  6422032

  6421952  6421972  6421992  6422012  6422032


6422116
   1  6422116   2  6422120   3  6422124   4  6422128
   5  6422132   6  6422136   7  6422140   8  6422144
   9  6422148  10  6422152  11  6422156  12  6422160
6422164
  13  6422164  14  6422168  15  6422172  16  6422176
   0  6422180   0  6422184   0  6422188   0  6422192
   0  6422196   0  6422200   0  6422204   0  6422208
*/
#include <stdio.h>

int main() {
  int i, num;
  int j = 1;  // Initialize j to 1 for factorial computation

  // Input
  printf("Enter the number: ");
  scanf("%d", &num);

  // Factorial calculation
  for (i = 1; i <= num; i++) {
    j = j * i;
  }

  // Output
  printf("The factorial of %d is %d\n", num, j);

  return 0;
}

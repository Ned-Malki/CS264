/*
 * powersum.c
 *
 *  Created on: 2024 09 12
 *      Author: Nedma
 */


#include "powersum.h"


/**
 * Detect if overflow occurs when computing b raised to the power of n.
 *
 * @param b - the base
 * @param n - the exponent
 * @return - 1 if overflow happens, 0 otherwise
 */
int power_overflow(int b, int n) {
    if (n < 0) {
        return 1;  // Negative exponents are not supported.
    }

    int result = 1;
    for (int i = 0; i < n; i++) {
        // Check if multiplying the result by the base would overflow
        if (result > INT_MAX / b) {
            return 1;  // Overflow detected
        }
        result *= b;
    }

    return 0;  // No overflow
}

/**
 * Compute and return b raised to the power of n.
 *
 * @param b - the base
 * @param n - the exponent
 * @return - b to the power of n if no overflow happens, 0 otherwise
 */
int mypower(int b, int n) {
    if (power_overflow(b, n)) {
        return 0;  // Return 0 if overflow happens
    }

    int result = 1;
    for (int i = 0; i < n; i++) {
        result *= b;
    }

    return result;
}

/**
 * Compute and return the sum of powers of b up to the nth exponent.
 *
 * @param b - the base
 * @param n - the exponent
 * @return - the sum of powers if no overflow happens, 0 otherwise
 */
int powersum(int b, int n) {
    int sum = 0;
    for (int i = 0; i <= n; i++) {
        int power = mypower(b, i);
        if (power == 0) {
            return 0;  // Return 0 if overflow occurs
        }
        sum += power;
        if (sum < 0) {
            return 0;  // Detect overflow in sum
        }
    }

    return sum;
}

/*
 * mychar.c
 *
 *  Created on: 2024 M09 11
 *      Author: Nedma
 */

#include "mychar.h"

// Function Definitions

/**
 * Determines the type of a char character.
 *
 * @param c - char type
 * @return - 0 if c is a digit
             1 if c is an arithmetic operator
             2 if c is the left parenthesis (
             3 if c is the right parenthesis )
             4 if c is an English letter;
             otherwise -1.
 */
int mytype(char c) {
    if (c >= '0' && c <= '9') {
        return 0;  // Digit
    } else if (c == '+' || c == '-' || c == '*' || c == '/') {
        return 1;  // Arithmetic operator
    } else if (c == '(') {
        return 2;  // Left parenthesis
    } else if (c == ')') {
        return 3;  // Right parenthesis
    } else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
        return 4;  // English letter
    } else {
        return -1; // Invalid character
    }
}

/**
 * Flip the case of an English character.
 *
 * @param c - char type
 * @return -  c's upper/lower case letter if c is a lower/upper case English letter.
 */
char case_flip(char c) {
    if (c >= 'a' && c <= 'z') {
        return c - 32;  // Convert to uppercase
    } else if (c >= 'A' && c <= 'Z') {
        return c + 32;  // Convert to lowercase
    }
    return c;  // Return character as-is if not a letter
}

/**
 * Convert digit character to the corresponding integer value.
 *
 * @param c - char type
 * @return  - c's corresponding integer value if c is a digit character.
 */
int digit_char_to_int(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';  // Convert char to integer
    }
    return -1;  // Return -1 if not a digit
}

/**
 * Process input and call the appropriate function.
 */
void processInput() {
    setbuf(stdout, NULL);  // Turns standard output buffering off

    char input;
    printf("Please enter a character\n");
    do
        input = getchar();
    while (isspace(input));

    while(input != '*'){
        int type = mytype(input);  // Determine character type
        if (type == 0) {  // If it's a digit
            int intValue = digit_char_to_int(input);
            printf("%c:%d,%d", input, input, intValue * intValue);
        } else if (type == 4) {  // If it's an English letter
            char flipped = case_flip(input);
            printf("%c:%d,%c", input, input, flipped);
        } else if (type == -1) {  // Invalid character
            printInvalid(input);
        } else {  // Other types (operator, parenthesis)
            printf("%c:%d", input, input);
        }
        printf("\n");

        printf("Please enter a character\n");
        do
            input = getchar();
        while (isspace(input));
    }
    printf("%c:quit\n", input);
}

/**
 * Print an invalid character message.
 */
void printInvalid(char input) {
    printf("%c:invalid", input);
}

/*
 * mychar.h
 *
 *  Created on: 2024 M09 11
 *      Author: Nedma
 */

#ifndef MYCHAR_H_
#define MYCHAR_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

// Function Prototypes

/**
 * Determines the type of a char character.
 *
 * @param c - char type
 * @return - 0 if c is a digit
             1 if c is an arithmetic operator
             2 if c is the left parenthesis (
             3 if c is the right parenthesis )
             4 if c is an English letter;
             otherwise -1.
 */
int mytype(char c);

/**
 * Flip the case of an English character.
 *
 * @param c - char type
 * @return -  c's upper/lower case letter if c is a lower/upper case English letter.
 */
char case_flip(char c);

/**
 * Convert digit character to the corresponding integer value.
 *
 * @param c - char type
 * @return  - c's corresponding integer value if c is a digit character.
 */
int digit_char_to_int(char c);

/**
 * Process the input character and perform actions based on its type.
 */
void processInput();

/**
 * Print invalid character message.
 *
 * @param input - the invalid character to be printed
 */
void printInvalid(char input);

#endif /* MYCHAR_H_ */

/*
 * quadratic.c
 *
 *  Created on: 2024 M09 11
 *      Author: Nedma
 */

#include "quadratic.h"

/**
 * Compute and return solution type of given quadratic equation ax*x + bx + c = 0
 *
 * @param a  - quadratic coefficient
 * @param b  - linear coefficient
 * @param c - constant coefficient
 * @return - 0 if not quadratic equation, i.e. a=0;
 *           1 for one unique real solution;
 *           2 for two distinct real solutions;
 *           3 for two complex solutiions
 */
int solution_type(float a, float b, float c){
    int roots = 0;
    float disc = ((b*b)-4*a*c);

    if (a == 0) // Checking to ensure it is quadratic
    {
        return 0;
    }
  
    else if (disc == 0) // If discriminant = 0, one real solution
    {
        return 1;
    }
    else if (disc > 0) // If discriminant > 0, 2 solutions
    {
        return 2;
    }
        else if (disc < 0) // If discriminant < 0 , solutions must be ∈ ℂ
    {
        return 3;
    }

}

/**
 * Compute and return unique or bigger real roots of given quadratic equation ax*x + bx + c = 0 of types 1 and 2.
 * @param a  - quadratic coefficient
 * @param b  - linear coefficient 
 * @param c - constant coefficient
 * @return - the unique real root or the bigger real root if the quadratic equation has two distinct real roots 
             Ohterwise, return 0.
 */
float real_root_big(float a, float b, float c) {
    int type = solution_type(a, b, c);

    if (type == 0){ // ensuring it is quadratic
        return 0;
    }
    else if (type == 1 || type == 2) {
        float disc = sqrt((b * b) - (4 * a * c));
        float plus_quad = (-b + disc) / (2 * a);
        float minus_quad = (-b - disc) / (2 * a);

        return plus_quad > minus_quad ? plus_quad : minus_quad; // Return bigger real root
    }
    else if(type == 3){

        return 0; // For complex solutions
        
    }

}

/**
 * Compute and return unique or smaller real roots of given quadratic equation ax*x + bx + c = 0 of types 1 and 2.
 * @param a  - quadratic coefficient
 * @param b  - linear coefficient 
 * @param c - constant coefficient
 * @return - the unique real root or the smaller real root if the quadratic equation has two distinct real roots 
             Ohterwise, return 0.
 */
float real_root_small(float a, float b, float c) {
    int type = solution_type(a, b, c);

    if (type == 0) {
        return 0; // Linear equation solution
    }

    if (type == 1 || type == 2) {
        float disc = sqrt((b * b) - (4 * a * c));
        float plus_quad = (-b + disc) / (2 * a);
        float minus_quad = (-b - disc) / (2 * a);

        return plus_quad < minus_quad ? plus_quad : minus_quad; // Return smaller real root
    }

    else if(type == 3){

        return 0; // For complex solutions
        
    }


}
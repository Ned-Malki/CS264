JobID: cp264oc-202405-lab1-a1
Name: type your name here
ID: type your student ID here

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab1

T1 Install and test GCC compiler
T1.1 [0/0/*] Utlity programs
T1.2 [0/0/*] Visual Studio Code
T1.3 [1/1/*] Install GNU GCC compiler
T1.4 [1/1/*] Test GCC compiler

T2 Programming using IDE
T2.1 [1/1/*] VS code for C
T2.2 [1/1/*] C project on Eclipse

T3 Explore C programs
T3.1 [1/1/*] Program structures and organization
T3.2 [1/1/*] Basics data types and variables
T3.3 [1/1/*] Arithmetic operations, casting
T3.4 [1/1/*] Bit operations
T3.5 [1/1/*] Flow control examples
T3.6 [1/1/*] Function examples

A1

Q1 [10/10/*] Char type and operations

Q2 [10/10/*] Simple power sum

Q3 [10/10/*] Real roots of quadratic equation

Total: [0/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  

Q1 output:
------------------
Test: mychar

Char	ASCII	MyType
   2	   50	     0
  digit_char_to_int: 2
Char	ASCII	MyType
   8	   56	     0
  digit_char_to_int: 8
Char	ASCII	MyType
   A	   65	     4
  caseflip: a
Char	ASCII	MyType
   a	   97	     4
  caseflip: A
Char	ASCII	MyType
   z	  122	     4
  caseflip: Z
Char	ASCII	MyType
   Z	   90	     4
  caseflip: z
Char	ASCII	MyType
   +	   43	     1
  operator
Char	ASCII	MyType
   -	   45	     1
  operator
Char	ASCII	MyType
   (	   40	     2
  left parenthesis: (
Char	ASCII	MyType
   )	   41	     3
  right parenthesis: )
Char	ASCII	MyType
   $	   36	    -1
  Not typed




Q2 output:


------------------
Test: power_overflow

power_overflow(2 9): 0
power_overflow(2 10): 0
power_overflow(2 20): 0
power_overflow(2 30): 0
power_overflow(2 31): 1

------------------
Test: mypower

mypower(2 2): 4
mypower(2 4): 16
mypower(2 6): 64
mypower(2 8): 256
mypower(2 10): 1024
mypower(2 30): 1073741824
mypower(3 2): 9
mypower(3 4): 81
mypower(3 6): 729
mypower(3 8): 6561
mypower(3 10): 59049
mypower(3 30): 0

------------------
Test: powersum

powersum(2 1): 3
powersum(2 2): 7
powersum(2 3): 15
powersum(2 4): 31
powersum(2 5): 63
powersum(2 6): 127
powersum(2 7): 255
powersum(2 8): 511
powersum(2 9): 1023
powersum(2 10): 2047
powersum(2 20): 2097151
powersum(2 30): 2147483647
powersum(2 31): 0
powersum(3 1): 4
powersum(3 2): 13
powersum(3 3): 40
powersum(3 4): 121
powersum(3 5): 364
powersum(3 6): 1093
powersum(3 7): 3280
powersum(3 8): 9841
powersum(3 9): 29524
powersum(3 10): 88573
powersum(3 20): 0
powersum(3 30): 0
powersum(3 31): 0

Q3 output:

------------------
------------------
Test: solution_type

solution_type(0.0 1.0 2.0): 0
solution_type(1.0 2.0 1.0): 1
solution_type(1.0 -4.0 4.0): 1
solution_type(1.0 2.0 2.0): 3
solution_type(1.0 -1.0 -6.0): 2

------------------
Test: real_root_small

real_root_small(0.0 1.0 2.0): 0.0
real_root_small(1.0 2.0 1.0): -1.0
real_root_small(1.0 -4.0 4.0): 2.0
real_root_small(1.0 2.0 2.0): 0.0
real_root_small(1.0 -1.0 -6.0): -2.0

------------------
Test: real_root_big

real_root_big(0.0 1.0 2.0): 0.0
real_root_big(1.0 2.0 1.0): -1.0
real_root_big(1.0 -4.0 4.0): 2.0
real_root_big(1.0 2.0 2.0): 0.0
real_root_big(1.0 -1.0 -6.0): 3.0
/* 
* Code example for CP264 Data Structures II
* Testing void pointers and addresses
* HBF 
*/
#include<stdio.h>

int a = 1;
int b = 2;

int main()
{
  static int c = 3;

  int x = 10;
  double y = 1.1;
  int*p = &x;
  double *py = &y;
  
  printf("Value of a: %d, address: %lu\n", a, (unsigned long int) &a);
  printf("Value of b: %d, address: %lu\n", b, (unsigned long int) &b);
  printf("Value of c: %d, address: %lu\n", c, (unsigned long int) &c);
  printf("Value of x: %d, address: %lu\n", x, (unsigned long int) &x);
  printf("Value of y: %f, address: %lu\n", y, (unsigned long int) &y);
 
  printf("Value in pointer variable p, %lu, sizeof p: %d, address of p:  %lu \n", (unsigned long int) p,  sizeof(p), (unsigned long int) &p);
  printf("Value in py: %lu, sizeof py: %d\n", (unsigned long int) py, sizeof(py));
  
  
  void *ptr;
  ptr = &x; 
  printf("void pointer address: %lu, casted value: %d\n", ptr,  *(int *) ptr);
  
  return 0;
}

/*
Value of a: 1, address: 4206600
Value of b: 2, address: 4206604
Value of c: 3, address: 4206608
Value of x: 10, address: 6684308
Value of y: 1.100000, address: 6684296
Value in pointer variable p, 6684308, sizeof p: 4, address of p:  6684292
Value in py: 6684296, sizeof py: 4
void pointer address: 6684308, casted value: 10
*/
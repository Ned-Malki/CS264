JobID: cp264oc-202405-lab2-a2
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab2

T1 C Debugging
T1.1 [2/2/*] Debug under command line
T1.2 [2/2/*] Debug under Eclipse

T2 Pointers
T2.1 [2/2/*] Test on pointers

T3 Arrays
T3.1 [2/2/*] Test on arrays

T4 2D Arrays
T4.1 [2/2/*] Test on 2D arrays

A2

Q1 [10/10/*] Computing Fibonacci numbers

Q2 [10/10/*] Array for polynomial

Q3 [0/10/*] Vector and Matrix

Total: [0/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  


--------------------------------------------------------------------------------------------------------
Q1 output:
--------------------------------------------------------------------------------------------------------
------------------
Test: iterative_fibonacci

iterative_fibonacci(0): 0
iterative_fibonacci(1): 1
iterative_fibonacci(2): 1
iterative_fibonacci(3): 2
iterative_fibonacci(4): 3
iterative_fibonacci(5): 5

------------------
Test: recursive_fibonacci

recursive_fibonacci(0): 0
recursive_fibonacci(1): 1
recursive_fibonacci(2): 1
recursive_fibonacci(3): 2
recursive_fibonacci(4): 3
recursive_fibonacci(5): 5

------------------
Test: dpbu_fibonacci

dpbu_fibonacci(0): 0
dpbu_fibonacci(1): 1
dpbu_fibonacci(2): 1
dpbu_fibonacci(3): 2
dpbu_fibonacci(4): 3
dpbu_fibonacci(5): 5

------------------
Test: dptd_fibonacci

dptd_fibonacci(0): 0
dptd_fibonacci(1): 1
dptd_fibonacci(2): 1
dptd_fibonacci(3): 2
dptd_fibonacci(4): 3
dptd_fibonacci(5): 5

------------------
Test: runtime, comparison

iterative_fibonacci(40): 102334155
recursive_fibonacci(40): 102334155
dpbu_fibonacci(40): 102334155
dptd_fibonacci(40): 102334155

**Function runtime measurement**
time_span(iterative_fibonacci(40) for 500000 times):35.0 (ms)
time_span(recursive_fibonacci(40) for 5 times):2814.0 (ms)
time_span(dpbu_fibonacci(40) for 500000 times):60.0 (ms)
time_span(dptd_fibonacci(40) for 50000 times):13.0 (ms)


**Comparisons**
time_span(recursive_fibonacci(40))/time_span(iterative_fibonacci(40)):8040000.0
time_span(dpbu_fibonacci(40))/time_span(iterative_fibonacci(40)):1.7
time_span(dptd_fibonacci(40))/time_span(iterative_fibonacci(40)):3.7
time_span(recursive_fibonacci(40))/time_span(dptd_fibonacci(40)):2164615.4



--------------------------------------------------------------------------------------------------------
Q2 output:

--------------------------------------------------------------------------------------------------------
------------------
Test: horner

p(x): 1.00*x^3+2.00*x^2+3.00*x^1+4.00
horner(p 0.00): 4.00
horner(p 1.00): 10.00
horner(p 10.00): 1234.00

------------------
Test: derivative

p'(x): 3.00*x^2+4.00*x^1+3.00
------------------
Test: newton

p(-2.00): -2.00
root: -1.65
p(-1.65): 0.00
p(-1.00): 2.00
root: -1.65
p(-1.65): 0.00


--------------------------------------------------------------------------------------------------------
Q3 output:

--------------------------------------------------------------------------------------------------------
------------------
Test: norm

v1:
1.0
2.0
2.0

norm(v1): 3.0
------------------
Test: dot_product

v1:
1.0
1.0
1.0

v2:
1.0
2.0
3.0

dot_product(v1 v2): 6.0
------------------
Test: matrix_multiply_vector

m:
1.0 2.0 3.0
4.0 5.0 6.0
7.0 8.0 9.0

v:
1.0
1.0
1.0

matrix_multiply_vector(m v v1)
v1:
6.0
15.0
24.0


------------------
Test: matrix_multiply_matrix

m1:
1.0 1.0 1.0
1.0 1.0 1.0
1.0 1.0 1.0

m2:
1.0 2.0 3.0
4.0 5.0 6.0
7.0 8.0 9.0

matrix_multiply_matrix(m1 m2 m3)
m3:
12.0 15.0 18.0
12.0 15.0 18.0
12.0 15.0 18.0





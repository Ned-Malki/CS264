/* 
* Code example for CP264 Data Structures II
* Testing pointer of pointer
* HBF 
*/

#include<stdio.h>

int main()
{
  int x = 10, *ptr, **pptr;
  ptr = &x;
  pptr = &ptr;
  
  printf("Value of x: %d\n", x);
  printf("Address of x in Hex: %p\n",&x);
  printf("Address of x in decimal: %lu\n",  &x);
  printf("Value of pointer variable ptr: %p (address in Hex)\n", ptr);
  printf("Address of pointer variable ptr (&ptr): %lu\n", &ptr);
  printf("The value pointed by ptr (*ptr): %d\n",*ptr);
  printf("&pptr: %lu\n", &pptr);
  printf("*pptr: %lu\n", *pptr);
  printf("**pptr: %d,  *(*pptr): %d\n", **pptr, *(*pptr));
  return 0;
}

/*
Value of x: 10
Address of x in Hex: 0065FE9C
Address of x in decimal: 6684316
Value of pointer variable ptr: 0065FE9C (address in Hex)
Address of pointer variable ptr (&ptr): 6684312
The value pointed by ptr (*ptr): 10
&pptr: 6684308
*pptr: 6684316
**pptr: 10,  *(*pptr): 10
*/

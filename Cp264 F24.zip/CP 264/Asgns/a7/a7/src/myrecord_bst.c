/*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
 *   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
 *  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
 * | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
 *  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
 *   \_____/                                                                                                         
 */

/*
 * Program signature and description
 */

#include <string.h>
#include <stdio.h>
#include <math.h>
#include "queue_stack.h"
#include "bst.h"
#include "myrecord_bst.h"

/* 
 * Adds a record to the BSTDS, updates count, mean, and stddev using incremental calculations.
 * @param ds - pointer to the BSTDS structure
 * @param record - RECORD data to be added
 */
void add_record(BSTDS *ds, RECORD record) {
	// Insert record into BST and update count
	bst_insert(&(ds->root), record);
	ds->count++;
	
	// Update mean using incremental algorithm
	float previous_mean = ds->mean;
	ds->mean = previous_mean + (record.score - previous_mean) / ds->count;

	// Update standard deviation based on new mean and score
	if (ds->count == 1) {
		ds->stddev = 0;
	} else {
		float score_difference = record.score - previous_mean;
		float adjusted_difference = score_difference * (record.score - ds->mean);
		ds->stddev = sqrt(((ds->count - 1) * ds->stddev * ds->stddev + adjusted_difference) / ds->count);
	}
}

/* 
 * Removes a record by name from the BSTDS, updating the count, mean, and stddev.
 * @param ds - pointer to the BSTDS structure
 * @param name - name of the record to be removed
 */
void remove_record(BSTDS *ds, char *name) {
	BSTNODE **node_ptr = &ds->root;
	BSTNODE *node_to_remove = NULL;

	// Locate the node to remove by name
	while (*node_ptr != NULL) {
		int comparison = strcmp(name, (*node_ptr)->data.name);
		if (comparison == 0) {
			node_to_remove = *node_ptr;
			break;
		} else if (comparison < 0) {
			node_ptr = &((*node_ptr)->left);
		} else {
			node_ptr = &((*node_ptr)->right);
		}
	}

	// If node not found, print a message and return
	if (node_to_remove == NULL) {
		printf("Node with name %s not found\n", name);
		return;
	}

	// Adjust mean and standard deviation for removal of node's data
	float previous_mean = ds->mean;
	float score_difference = node_to_remove->data.score - previous_mean;
	ds->count--;

	if (ds->count == 0) {
		ds->mean = 0;
		ds->stddev = 0;
	} else {
		ds->mean = previous_mean - (score_difference / ds->count);
		float adjusted_diff_square = score_difference * (node_to_remove->data.score - ds->mean);

		if (ds->count == 1) {
			ds->stddev = 0;
		} else {
			ds->stddev = sqrt(((ds->count + 1) * (ds->stddev * ds->stddev) - adjusted_diff_square) / ds->count);
		}
	}

	// Delete the node from BST
	bst_delete(node_ptr, name);
}

/* 
 * Cleans up the BSTDS by freeing all nodes and resetting statistics.
 * @param ds - pointer to the BSTDS structure
 */
void bstds_clean(BSTDS *ds) {
	bst_clean(&ds->root);
	ds->count = 0;
	ds->mean = 0;
	ds->stddev = 0;
}

/*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
 *   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
 *  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
 * | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
 *  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
 *   \_____/                                                                                                         
 */

#include <stdio.h>
#include <stdlib.h>
#include "queue_stack.h"
#include "tree.h"

/* 
 * Computes tree properties such as height and order.
 * @param root - root of the tree
 * @returns TPROPS containing order and height
 */
TPROPS tree_property(TNODE *root) {
	TPROPS props = { 0 };
	if (root == NULL) return props;

	// Calculate order (number of nodes) and height
	props.order = 1 + tree_property(root->left).order + tree_property(root->right).order;
	int left_height = 1 + tree_property(root->left).height;
	int right_height = 1 + tree_property(root->right).height;
	props.height = (left_height > right_height) ? left_height : right_height;

	return props;
}

/* 
 * Traverses the tree in preorder and prints each node's data.
 * @param root - root of the tree
 */
void preorder(TNODE *root) {
	if (root != NULL) {
		printf("%c ", root->data);
		preorder(root->left);
		preorder(root->right);
	}
}

/* 
 * Traverses the tree in inorder and prints each node's data.
 * @param root - root of the tree
 */
void inorder(TNODE *root) {
	if (root != NULL) {
		inorder(root->left);
		printf("%c ", root->data);
		inorder(root->right);
	}
}

/* 
 * Traverses the tree in postorder and prints each node's data.
 * @param root - root of the tree
 */
void postorder(TNODE *root) {
	if (root != NULL) {
		postorder(root->left);
		postorder(root->right);
		printf("%c ", root->data);
	}
}

/* 
 * Performs breadth-first traversal and prints each node's data.
 * @param root - root of the tree
 */
void bforder(TNODE *root) {
	if (root == NULL) return;

	QUEUE queue = { 0 };
	enqueue(&queue, root);

	while (queue.front) {
		TNODE *current = (TNODE*) dequeue(&queue);
		printf("%c ", current->data);

		if (current->left) enqueue(&queue, current->left);
		if (current->right) enqueue(&queue, current->right);
	}

	clean_queue(&queue);
}

/* 
 * Searches for a node with a specific value using breadth-first search.
 * @param root - root of the tree
 * @param val - value to search for
 * @returns pointer to the node with the value, or NULL if not found
 */
TNODE* bfs(TNODE *root, char val) {
	if (root == NULL) return NULL;

	QUEUE queue = { 0 };
	enqueue(&queue, root);

	while (queue.front) {
		TNODE *node = (TNODE*) dequeue(&queue);
		if (node->data == val) {
			clean_queue(&queue);
			return node;
		}
		if (node->left) enqueue(&queue, node->left);
		if (node->right) enqueue(&queue, node->right);
	}

	clean_queue(&queue);
	return NULL;
}

/* 
 * Searches for a node with a specific value using depth-first search.
 * @param root - root of the tree
 * @param val - value to search for
 * @returns pointer to the node with the value, or NULL if not found
 */
TNODE* dfs(TNODE *root, char val) {
	if (root == NULL) return NULL;

	STACK stack = { 0 };
	push(&stack, root);

	while (stack.top) {
		TNODE *node = (TNODE*) pop(&stack);
		if (node->data == val) {
			clean_stack(&stack);
			return node;
		}
		if (node->right) push(&stack, node->right);
		if (node->left) push(&stack, node->left);
	}

	clean_stack(&stack);
	return NULL;
}

/* 
 * Creates a new tree node with the given value.
 * @param val - value for the new node
 * @returns pointer to the new node
 */
TNODE* new_node(char val) {
	TNODE *np = (TNODE*) malloc(sizeof(TNODE));
	if (np != NULL) {
		np->data = val;
		np->left = NULL;
		np->right = NULL;
	}
	return np;
}

/* 
 * Frees all nodes in the tree.
 * @param rootp - pointer to the root of the tree
 */
void tree_clean(TNODE **rootp) {
	TNODE *node = *rootp;
	if (node) {
		tree_clean(&node->left);
		tree_clean(&node->right);
		free(node);
	}
	*rootp = NULL;
}

/* 
 * Inserts a new node into the tree in level order.
 * @param rootp - pointer to the root of the tree
 * @param val - value to be inserted
 */
void insert_tree(TNODE **rootp, char val) {
	if (*rootp == NULL) {
		*rootp = new_node(val);
	} else {
		QUEUE queue = { 0 };
		enqueue(&queue, *rootp);

		while (queue.front) {
			TNODE *node = (TNODE*) dequeue(&queue);
			if (node->left == NULL) {
				node->left = new_node(val);
				break;
			} else {
				enqueue(&queue, node->left);
			}
			if (node->right == NULL) {
				node->right = new_node(val);
				break;
			} else {
				enqueue(&queue, node->right);
			}
		}
		clean_queue(&queue);
	}
}

/*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
 *   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
 *  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
 * | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
 *  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
 *   \_____/                                                                                                         
 */

/*
 * Program signature and description
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"

// Function prototypes
BSTNODE* new_node(RECORD data);
BSTNODE* extract_smallest_node(BSTNODE **rootp);

/* Searches for a node by key in the BST */
BSTNODE* bst_search(BSTNODE *root, char *key) {
	// Return the node if root is NULL or matches the key
	if (root == NULL || strcmp(root->data.name, key) == 0) {
		return root;
	}

	// Recursively search the left or right subtree
	if (strcmp(root->data.name, key) < 0) {
		return bst_search(root->right, key);
	} else {
		return bst_search(root->left, key);
	}
}

/* Inserts a new node with the given data into the BST */
void bst_insert(BSTNODE **rootp, RECORD data) {
	BSTNODE *root = *rootp;

	// Insert new node if root is NULL
	if (root == NULL) {
		*rootp = new_node(data);
		return;
	}

	// Recursively insert into the left or right subtree
	if (strcmp(root->data.name, data.name) < 0) {
		bst_insert(&root->right, data);
	} else {
		bst_insert(&root->left, data);
	}
}

/* Deletes a node with the given key from the BST */
void bst_delete(BSTNODE **rootp, char *key) {
	BSTNODE *root = *rootp;

	// Base case: tree is empty
	if (root == NULL) return;

	// Traverse the tree to locate the node
	if (strcmp(root->data.name, key) < 0) {
		bst_delete(&root->right, key);
	} else if (strcmp(root->data.name, key) > 0) {
		bst_delete(&root->left, key);
	} else {
		// Node with key found: process for deletion
		BSTNODE *temp = root;

		// Case 1: Node has only one child or none
		if (root->left == NULL) {
			*rootp = root->right;
			free(temp);
		} else if (root->right == NULL) {
			*rootp = root->left;
			free(temp);
		} else {
			// Case 2: Node has two children
			temp = extract_smallest_node(&root->right);
			root->data = temp->data;
			free(temp);
		}
	}
}

/* Creates a new node with the provided data */
BSTNODE* new_node(RECORD data) {
	BSTNODE *np = (BSTNODE*) malloc(sizeof(BSTNODE));
	if (np) {
		memcpy(&(np->data), &data, sizeof(RECORD));
		np->left = NULL;
		np->right = NULL;
	}
	return np;
}

/* Extracts and returns the smallest node from the subtree */
BSTNODE* extract_smallest_node(BSTNODE **rootp) {
	BSTNODE *p = *rootp, *parent = NULL;

	// Traverse left to find the smallest node
	while (p && p->left) {
		parent = p;
		p = p->left;
	}

	// Adjust pointers to remove the smallest node
	if (parent == NULL) {
		*rootp = p->right;
	} else {
		parent->left = p->right;
	}

	p->left = NULL;
	p->right = NULL;
	return p;
}

/* Frees all nodes in the BST */
void bst_clean(BSTNODE **rootp) {
	BSTNODE *root = *rootp;

	// Recursively free left and right subtrees
	if (root) {
		bst_clean(&root->left);
		bst_clean(&root->right);
		free(root);
	}
	*rootp = NULL;
}

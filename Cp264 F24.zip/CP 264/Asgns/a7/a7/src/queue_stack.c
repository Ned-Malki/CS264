/*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
 *   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
 *  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
 * | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
 *  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
 *   \_____/                                                                                                         
 */

#include <stdio.h>
#include <stdlib.h>
#include "queue_stack.h"

/* Adds an item to the end of the queue */
void enqueue(QUEUE *qp, void *data) {
	if (qp && data) {
		NODE *new_node = (NODE*) malloc(sizeof(NODE));
		if (new_node != NULL) {
			new_node->data = data;
			new_node->next = NULL;

			// Update front and rear pointers
			if (qp->front == NULL) {
				qp->front = new_node;
				qp->rear = new_node;
			} else {
				qp->rear->next = new_node;
				qp->rear = new_node;
			}
		}
	}
}

/* Removes an item from the front of the queue and returns its data */
void* dequeue(QUEUE *qp) {
	void *data = NULL;
	if (qp && qp->front) {
		NODE *front_node = qp->front;
		data = front_node->data;

		// Update front and rear pointers if queue becomes empty
		if (qp->front == qp->rear) {
			qp->front = NULL;
			qp->rear = NULL;
		} else {
			qp->front = front_node->next;
		}
		free(front_node);
	}
	return data;
}

/* Empties the queue and frees all allocated nodes */
void clean_queue(QUEUE *qp) {
	if (qp) {
		NODE *temp, *current = qp->front;
		while (current) {
			temp = current;
			current = current->next;
			free(temp);
		}
		qp->front = NULL;
		qp->rear = NULL;
	}
}

/* Pushes an item onto the stack */
void push(STACK *sp, void *data) {
	if (sp && data) {
		NODE *new_node = (NODE*) malloc(sizeof(NODE));
		if (new_node) {
			new_node->data = data;
			new_node->next = sp->top;
			sp->top = new_node;
		}
	}
}

/* Removes and returns the top item from the stack */
void* pop(STACK *sp) {
	void *data = NULL;
	if (sp && sp->top) {
		NODE *top_node = sp->top;
		data = top_node->data;
		sp->top = top_node->next;
		free(top_node);
	}
	return data;
}

/* Empties the stack and frees all allocated nodes */
void clean_stack(STACK *sp) {
	if (sp) {
		NODE *temp, *current = sp->top;
		while (current) {
			temp = current;
			current = current->next;
			free(temp);
		}
		sp->top = NULL;
	}
}

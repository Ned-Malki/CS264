JobID: cp264oc-202405-lab9-a9
Name: type your name here
ID: type your student ID here

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab9

T1 Hash tables
T1.1 [5/5/*] Read and test hash tables

T2 Heaps
T2.1 [5/5/*] Read and test Heaps

A9

Q1 [10/10/*] Chained hash table

Q2 [8/8/*] Hash table for symbolic expression

Q3 [12/12/*] Binary heap

Total: [0/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  

Q1 output:




------------------
Test: hash

hash(a): 2
hash(b): 3
hash(c): 4
hash(d): 0
hash(e): 1
hash(f): 2
hash(g): 3

------------------
Test: new_hashtable

new_hashtable(5): size 5 count 0
------------------
Test: hashtable_insert

hashtable_insert(a 0): count 1 2 (a 0)
hashtable_insert(b 1): count 2 2 (a 0) 3 (b 1)
hashtable_insert(c 2): count 3 2 (a 0) 3 (b 1) 4 (c 2)
hashtable_insert(d 3): count 4 0 (d 3) 2 (a 0) 3 (b 1) 4 (c 2)
hashtable_insert(e 4): count 5 0 (d 3) 1 (e 4) 2 (a 0) 3 (b 1) 4 (c 2)
hashtable_insert(f 5): count 6 0 (d 3) 1 (e 4) 2 (f 5) (a 0) 3 (b 1) 4 (c 2)
hashtable_insert(g 6): count 7 0 (d 3) 1 (e 4) 2 (f 5) (a 0) 3 (g 6) (b 1) 4 (c 2) 

------------------
Test: hashtable_search

search(a):(a,0)
search(b):(b,1)
search(f):(f,5)
search(h):NULL

------------------
Test: hashtable_delete

hashtable_delete(a): count 6 0 (d 3) 1 (e 4) 2 (f 5) 3 (g 6) (b 1) 4 (c 2)
hashtable_delete(b): count 5 0 (d 3) 1 (e 4) 2 (f 5) 3 (g 6) 4 (c 2) 
hashtable_delete(f): count 4 0 (d 3) 1 (e 4) 3 (g 6) 4 (c 2)
hashtable_delete(h): count 4 0 (d 3) 1 (e 4) 3 (g 6) 4 (c 2)





Q2 output:



keyalue_tests_hashtable: (d 3) (a 10) (b 8) (c 2) 
------------------
Test: infix_to_postfix

infix_to_postfix_symbol(a+b): 10 8 +
infix_to_postfix_symbol(a+b+c+d): 10 8 + 2 + 3 +
infix_to_postfix_symbol(a+b*c): 10 8 2 * +
infix_to_postfix_symbol((a-b)*(c+d)): 10 8 - 2 3 + *

------------------
Test: evaluate_infix_symbol

evaluate_infix_symbol(a+b): 18
evaluate_infix_symbol(a+b+c+d): 23
evaluate_infix_symbol(a+b*c): 26
evaluate_infix_symbol((a-b)*(c+d)): 10

------------------
Test: evaluate_statement

evaluate_statement(a=10): a 10
evaluate_statement(b=8): b 8
evaluate_statement(d=2): d 2
evaluate_statement(c=(a+b)*(a-b)): c 36
evaluate_statement(b=d*c): b 72
evaluate_statement(e=12): e 12
evaluate_statement(f=e/d): f 6
evaluate_statement(b): b 72
evaluate_statement(k): null




Q3 output:


------------------
Test: new_heap

new_heap(4): size 0 capacity 4 (index key data)

------------------
Test: heap_insert

heap_insert: size 0 capacity 4 (index key data)
heap_insert(4 10): size 1 capacity 4
heap_insert(5 9): size 2 capacity 4
heap_insert(8 6): size 3 capacity 4
heap_insert(7 7): size 4 capacity 4
Heap overflow
heap_insert(6 8): size 4 capacity 4
Heap overflow
heap_insert(12 2): size 4 capacity 4
Heap overflow
heap_insert(9 5): size 4 capacity 4
after heap_insert: size 4 capacity 4 (index key data) (0 4 10) (1 5 9) (2 8 6) (3 7 7)

------------------
Test: heap_search_data

heap_search_data: size 4 capacity 4 (index key data) (0 4 10) (1 5 9) (2 8 6) (3 7 7) 
heap_search_data(10): index 0 key 4 data 10
heap_search_data(6): index 2 key 8 data 6
heap_search_data(1): not found

------------------
Test: heap_change_key

heap_change_key: size 4 capacity 4 (index key data) (0 4 10) (1 5 9) (2 8 6) (3 7 7)
heap_change_key(0 8): (0 4 10) -> (0 5 9)
heap_change_key(3 1): (3 8 10) -> (0 1 10)
after heap_change_key: size 4 capacity 4 (index key data) (0 1 10) (1 5 9) (2 8 6) (3 7 7) 

Heap overflow
Heap overflow
Heap overflow
------------------
Test: heap_extract_min and heap_find_min

heap_extract_min: size 4 capacity 4 (index key data) (0 4 10) (1 5 9) (2 8 6) (3 7 7)
heap_extract_min(0): key 4 data 10  size 3 capacity 4
heap_find_min(0): key 5 data 9
heap_extract_min(1): key 5 data 9  size 2 capacity 4
heap_find_min(1): key 7 data 7
heap_extract_min(2): key 7 data 7  size 1 capacity 4
heap_find_min(2): key 8 data 6



/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/


#ifndef HASH_H
#define HASH_H

#include <stdio.h>

/* Define structure HASHDATA type to represent key (string) value (int) pair. */
typedef struct {
    char key[20];  // key string
    int value;     // value associated with the key
} HASHDATA;

/* Define structure HASHNODE as linked list node to represent hash data with the same hashed value. */
typedef struct hashnode {
    char key[20];             // key string
    int value;                // value associated with the key
    struct hashnode *next;    // pointer to the next node
} HASHNODE;

/* Define HASHTABLE structure type for linked hash table. */
typedef struct hashtable {
    HASHNODE **hna;  // pointer to the array of HASHNODE pointers
    int size;        // hash table size, i.e., the modular or length of index array
    int count;       // number of data elements in the hash table
} HASHTABLE;

/* Hash function that hashes key string to an integer of modular of hash table size.
 * @param key - input key string
 * @param size - modular value
 * @return - sum of ASCII code value of the key string % size
 */
int hash(char *key, int size);

/* Create dynamically a chained hash table of the given size.
 * @param size - hash table size, i.e., the length of index array.
 * @return - pointer to the newly created HASHTABLE
 */
HASHTABLE *new_hashtable(int size);

/* Insert key-value data into HASHTABLE, maintaining increasing order of keys in each linked list.
 * @param ht - pointer to a HASHTABLE
 * @param key - key string
 * @param value - integer value
 * @return - if the HASHNODE of the key exists, updates its value and returns 0; 
 *           otherwise inserts into the hash table and returns 1
 */
int hashtable_insert(HASHTABLE *ht, char *key, int value);

/* Search the hash table and return a pointer to the found HASHNODE.
 * @param ht - pointer to a HASHTABLE
 * @param key - input search key string
 * @return - pointer to the found HASHNODE, otherwise NULL
 */
HASHNODE *hashtable_search(HASHTABLE *ht, char *key);

/* Delete hashnode by key.
 * @param ht - pointer to a HASHTABLE
 * @param key - delete key string
 * @return - if the named hash node exists, deletes it and returns 1; otherwise returns 0
 */
int hashtable_delete(HASHTABLE *ht, char *key);

/* Delete all linked lists and reset the count to 0.
 * @param ht - pointer to a HASHTABLE
 */
void hashtable_clean(HASHTABLE **ht);

#endif // HASH_H

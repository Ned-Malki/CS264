/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common_queue_stack.h"
#include "expression_symbol.h"
#include "hash.h"

QUEUE infix_to_postfix_symbol(HASHTABLE *ht, char *infixstr) {
    QUEUE queue = {0};
    STACK stack = {0};  
    char *p = infixstr;
    int sign = 1;
    int num = 0;
    char symbol[11] = {0};

    while (*p) {
        if (*p == '-' && (p == infixstr || *(p-1) == '(')) {
            sign = -1;
        }  
        else if (mytype(*p) == 0) { // Digit
            num = *p - '0';
            while (*(p + 1) >= '0' && *(p + 1) <= '9') {
                num = num * 10 + (*(p + 1) - '0');
                p++;
            }
            enqueue(&queue, new_node(sign * num, 0)); // Enqueue number as operand
            sign = 1;  
        }
        else if (mytype(*p) == 2) { // '('
            push(&stack, new_node('(', 2));
        }
        else if (mytype(*p) == 3) { // ')'
            while (stack.top) {
                if (stack.top->type == 2) { // If '(' is found
                    free(pop(&stack));
                    break;
                }
                enqueue(&queue, pop(&stack));  
            }
        } 
        else if (mytype(*p) == 1) { // Operator
            while (stack.top && stack.top->type == 1 && mypriority(stack.top->data) >= mypriority(*p))
                enqueue(&queue, pop(&stack));
            push(&stack, new_node(*p, 1));
        }
        else if (mytype(*p) == 4) { // Variable
            char *q = symbol;
            while ((p && mytype(*p) == 4) || (*p >= '0' && *p <= '9')) {
                *q++ = *p++;
            }
            p--; // Adjust position after the loop
            *q = '\0';
            HASHNODE *hnp = hashtable_search(ht, symbol);
            if (hnp) {
                enqueue(&queue, new_node(hnp->value, 0)); // Enqueue the value of the variable
            } else {
                printf("Error: Undefined variable '%s'\n", symbol);
                exit(1);
            }
        }
        p++;
    }
  
    while (stack.top) {    
        enqueue(&queue, pop(&stack));  
    }
  
    return queue;
}

int evaluate_infix_symbol(HASHTABLE *ht, char *infixstr) {
    QUEUE postfix_queue = infix_to_postfix_symbol(ht, infixstr);
    return evaluate_postfix(postfix_queue);
}

int evaluate_postfix(QUEUE queue) {
    STACK stack = {0};
    while (queue.front) {
        NODE *node = dequeue(&queue);
        if (node->type == 0) { // Operand
            push(&stack, new_node(node->data, 0));
        } else if (node->type == 1) { // Operator
            int b = pop(&stack)->data; // Second operand
            int a = pop(&stack)->data; // First operand
            int result = 0;
            switch (node->data) {
                case '+': result = a + b; break;
                case '-': result = a - b; break;
                case '*': result = a * b; break;
                case '/': 
                    if (b == 0) {
                        printf("Error: Division by zero\n");
                        exit(1);
                    }
                    result = a / b; 
                    break;
                case '%': 
                    if (b == 0) {
                        printf("Error: Division by zero\n");
                        exit(1);
                    }
                    result = a % b; 
                    break;
                default:
                    printf("Error: Unknown operator '%c'\n", node->data);
                    exit(1);
            }
            push(&stack, new_node(result, 0));
        }
        free(node); // Free node after processing
    }
    int result = pop(&stack)->data;
    return result;
}

HASHDATA evaluate_statement(HASHTABLE *ht, char* statement) {
    HASHDATA hd = {0};
    char line[80] = {0};
    strcpy(line, statement);
    char *p = line, *dp = line;
    while (*p) {
        if (*p != ' ') {
            *dp = *p;
            dp++;
        }
        p++;
    }
    char name[20] = {0};
    char *eqp = strstr(line, "=");
    if (eqp) {
        for (p = line, dp = name; p != eqp; p++)
            *dp = *p;
        if ((name[0] >= 'a' && name[0] <= 'z') || (name[0] >= 'A' && name[0] <= 'Z')) {
            int value = evaluate_infix_symbol(ht, eqp + 1);
            hashtable_insert(ht, name, value);
            strcpy(hd.key, name);
            hd.value = value;
        }
    } else {
        strcpy(name, line);
        if ((name[0] >= 'a' && name[0] <= 'z') || (name[0] >= 'A' && name[0] <= 'Z')) {
            HASHNODE *hnp = hashtable_search(ht, name);
            if (hnp) {
                strcpy(hd.key, name);
                hd.value = hnp->value;
            }
        }
    }
    return hd;
}



int mypriority(char op) {
    if (op == '/' || op == '*' || op == '%') return 1;
    if (op == '+' || op == '-') return 0;
    return -1; // Invalid operator
}

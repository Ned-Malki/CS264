/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

// Hash function: returns the index for a given key
int hash(char *key, int size) {
    int hash_value = 0;
    for (int i = 0; key[i] != '\0'; i++) {
        hash_value += key[i]; // Sum ASCII values
    }
    return hash_value % size; // Modular operation
}

// Create a new hash table
HASHTABLE *new_hashtable(int size) {
    HASHTABLE *ht = (HASHTABLE *)malloc(sizeof(HASHTABLE));
    if (!ht) {
        perror("Failed to allocate memory for hash table");
        return NULL;
    }
    ht->hna = (HASHNODE **)calloc(size, sizeof(HASHNODE *));
    if (!ht->hna) {
        perror("Failed to allocate memory for hash table buckets");
        free(ht);
        return NULL;
    }
    ht->size = size;
    ht->count = 0;
    return ht;
}

// Search for a key in the hash table
HASHNODE *hashtable_search(HASHTABLE *ht, char *key) {
    int index = hash(key, ht->size);
    HASHNODE *current = ht->hna[index];
    while (current) {
        if (strcmp(current->key, key) == 0) {
            return current;
        }
        current = current->next;
    }
    return NULL; // Key not found
}

// Insert a key-value pair into the hash table
int hashtable_insert(HASHTABLE *ht, char *key, int value) {
    int index = hash(key, ht->size);
    HASHNODE *current = ht->hna[index];
    HASHNODE *prev = NULL;

    // Traverse the linked list to check for existing key
    while (current) {
        if (strcmp(current->key, key) == 0) {
            current->value = value; // Update value if key exists
            return 0; // Updated existing node
        }
        prev = current;
        current = current->next;
    }

    // Key not found, insert new node
    HASHNODE *new_node = (HASHNODE *)malloc(sizeof(HASHNODE));
    if (!new_node) {
        perror("Failed to allocate memory for hash node");
        return -1; // Memory allocation error
    }
    strcpy(new_node->key, key);
    new_node->value = value;
    new_node->next = ht->hna[index];
    ht->hna[index] = new_node;
    ht->count++;
    return 1; // New node inserted
}

// Delete a node by key
int hashtable_delete(HASHTABLE *ht, char *key) {
    int index = hash(key, ht->size);
    HASHNODE *current = ht->hna[index];
    HASHNODE *prev = NULL;

    while (current) {
        if (strcmp(current->key, key) == 0) {
            if (prev) {
                prev->next = current->next; // Link previous node to next
            } else {
                ht->hna[index] = current->next; // Update head in bucket
            }
            free(current);
            ht->count--;
            return 1; // Node deleted
        }
        prev = current;
        current = current->next;
    }
    return 0; // Key not found
}

// Clean up the entire hash table
void hashtable_clean(HASHTABLE **ht) {
    if (!ht || !*ht) return;

    HASHTABLE *table = *ht;
    for (int i = 0; i < table->size; i++) {
        HASHNODE *current = table->hna[i];
        while (current) {
            HASHNODE *temp = current;
            current = current->next;
            free(temp);
        }
    }

    free(table->hna); // Free bucket array
    free(table);      // Free the table structure
    *ht = NULL;       // Set pointer to NULL
}

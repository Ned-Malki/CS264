/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/
 
#ifndef EXPRESSION_SYMBOL_H
#define EXPRESSION_SYMBOL_H

#include "common_queue_stack.h"
#include "hash.h"

QUEUE infix_to_postfix_symbol(HASHTABLE *ht, char *infixstr);

int evaluate_infix_symbol(HASHTABLE *ht, char *infixstr);

int evaluate_postfix(QUEUE queue);

HASHDATA evaluate_statement(HASHTABLE *ht, char* statement);

int mypriority(char op);

#endif
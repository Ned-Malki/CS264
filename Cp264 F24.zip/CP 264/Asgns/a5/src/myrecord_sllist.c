/*
 * @author Nedma
 * @version 2024-10-09
 */ 
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "myrecord_sllist.h"




NODE *sll_search(SLL *sllp, char *name) {
// your implementation
}




void sll_insert(SLL *sllp, char *name, float score) {
// your implementation
// need to update the length
}




int sll_delete(SLL *sllp, char *name) {
// your implementation
// need to update the length
}




void sll_clean(SLL *sllp) {
    NODE *temp, *ptr = sllp->start;
    while (ptr != NULL) {
        temp = ptr;
        ptr = ptr->next;
        free(temp);
    }
    sllp->start = NULL;
    sllp->length = 0;
}








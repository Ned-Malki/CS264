/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/

 
#ifndef AVL_H
#define AVL_H

typedef struct record {
  char name[20];
  float score;
} RECORD;

typedef struct avlnode {
    RECORD data;
    int height;
    struct avlnode *left;
    struct avlnode *right;
} AVLNODE;

void avl_insert(AVLNODE **rootp, RECORD data);

void avl_delete(AVLNODE **rootp, char *key);

AVLNODE *avl_search(AVLNODE *root, char *name);

void avl_clean(AVLNODE **rootp);

int height(AVLNODE *root);

int balance_factor(AVLNODE *np);

AVLNODE *rotate_left(AVLNODE *np);

AVLNODE *rotate_right(AVLNODE *root);

#endif
/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"

int height(AVLNODE *root) {
    return root ? root->height : -1;
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

int balance_factor(AVLNODE *np) {
    return np ? height(np->left) - height(np->right) : 0;
}

AVLNODE *rotate_left(AVLNODE *np) {
    AVLNODE *temp = np->right;
    np->right = temp->left;
    temp->left = np;
    np->height = max(height(np->left), height(np->right)) + 1;
    temp->height = max(height(temp->right), np->height) + 1;
    return temp;
}

AVLNODE *rotate_right(AVLNODE *root) {
    AVLNODE *temp = root->left;
    root->left = temp->right;
    temp->right = root;
    root->height = max(height(root->left), height(root->right)) + 1;
    temp->height = max(height(temp->left), root->height) + 1;
    return temp;
}

AVLNODE *balance(AVLNODE *root) {
    int bf = balance_factor(root);
    if (bf > 1) {
        if (balance_factor(root->left) < 0)
            root->left = rotate_left(root->left);
        root = rotate_right(root);
    } else if (bf < -1) {
        if (balance_factor(root->right) > 0)
            root->right = rotate_right(root->right);
        root = rotate_left(root);
    }
    return root;
}

void avl_insert(AVLNODE **rootp, RECORD data) {
    AVLNODE *root = *rootp;
    if (!root) {
        root = (AVLNODE *)malloc(sizeof(AVLNODE));
        root->data = data;
        root->height = 0;
        root->left = root->right = NULL;
        *rootp = root;
    } else if (strcmp(data.name, root->data.name) < 0) {
        avl_insert(&root->left, data);
    } else if (strcmp(data.name, root->data.name) > 0) {
        avl_insert(&root->right, data);
    }
    root->height = max(height(root->left), height(root->right)) + 1;
    *rootp = balance(root);
}

AVLNODE *find_min(AVLNODE *root) {
    while (root->left)
        root = root->left;
    return root;
}

void avl_delete(AVLNODE **rootp, char *key) {
    AVLNODE *root = *rootp;
    if (!root)
        return;
    if (strcmp(key, root->data.name) < 0) {
        avl_delete(&root->left, key);
    } else if (strcmp(key, root->data.name) > 0) {
        avl_delete(&root->right, key);
    } else {
        if (!root->left) {
            AVLNODE *temp = root->right;
            free(root);
            *rootp = temp;
        } else if (!root->right) {
            AVLNODE *temp = root->left;
            free(root);
            *rootp = temp;
        } else {
            AVLNODE *temp = find_min(root->right);
            root->data = temp->data;
            avl_delete(&root->right, temp->data.name);
        }
    }
    if (*rootp) {
        root = *rootp;
        root->height = max(height(root->left), height(root->right)) + 1;
        *rootp = balance(root);
    }
}

AVLNODE *avl_search(AVLNODE *root, char *name) {
    if (!root)
        return NULL;
    if (strcmp(name, root->data.name) < 0)
        return avl_search(root->left, name);
    else if (strcmp(name, root->data.name) > 0)
        return avl_search(root->right, name);
    else
        return root;
}

void avl_clean(AVLNODE **rootp) {
    AVLNODE *root = *rootp;
    if (root) {
        avl_clean(&root->left);
        avl_clean(&root->right);
        free(root);
        *rootp = NULL;
    }
}

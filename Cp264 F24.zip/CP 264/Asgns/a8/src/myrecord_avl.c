/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/

 
#ifndef AVL_H
#define AVL_H

typedef struct record {
  char name[20];
  float score;
} RECORD;

typedef struct avlnode {
    RECORD data;
    int height;
    struct avlnode *left;
    struct avlnode *right;
} AVLNODE;

void avl_insert(AVLNODE **rootp, RECORD data);

void avl_delete(AVLNODE **rootp, char *key);

AVLNODE *avl_search(AVLNODE *root, char *name);

void avl_clean(AVLNODE **rootp);

int height(AVLNODE *root);

int balance_factor(AVLNODE *np);

AVLNODE *rotate_left(AVLNODE *np);

AVLNODE *rotate_right(AVLNODE *root);

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "avl.h"
#include "myrecord_avl.h"

void merge_avl(AVLNODE **dest_rootp, AVLNODE **source_rootp) {
    if (*source_rootp) {
        merge_avl(dest_rootp, &(*source_rootp)->left);
        merge_avl(dest_rootp, &(*source_rootp)->right);
        avl_insert(dest_rootp, (*source_rootp)->data);  // Insert source data into dest
    }
}

void merge_avlds(AVLDS *dest, AVLDS *source) {
    merge_avl(&dest->root, &source->root);

    // Update statistics
    dest->count += source->count;
    dest->mean = ((dest->mean * dest->count) + (source->mean * source->count)) / (dest->count + source->count);

    float combined_variance = ((dest->stddev * dest->stddev * dest->count) + 
                              (source->stddev * source->stddev * source->count)) / 
                              (dest->count + source->count);
    dest->stddev = sqrt(combined_variance);

    avlds_clean(source);  // Clean up the source AVLDS structure
}

void avlds_clean(AVLDS *ds) {
    avl_clean(&ds->root);
    ds->count = 0;
    ds->mean = 0;
    ds->stddev = 0;
}

void add_record(AVLDS *tree, RECORD data) {
    if (avl_search(tree->root, data.name) == NULL) {
        avl_insert(&(tree->root), data);
        
        float previous_mean = tree->mean;
        tree->count += 1;
        tree->mean = (previous_mean * (tree->count - 1) + data.score) / tree->count;
        
        float new_variance = ((tree->stddev * tree->stddev * (tree->count - 1)) + 
                             (data.score - previous_mean) * (data.score - tree->mean)) / 
                             tree->count;
        tree->stddev = sqrt(new_variance);
    } else {
        printf("record exists\n");
    }
}

void remove_record(AVLDS *tree, char *name) {
    AVLNODE *node = avl_search(tree->root, name);
    if (node != NULL) {
        float score = node->data.score;
        avl_delete(&(tree->root), name);

        float previous_mean = tree->mean;
        tree->count -= 1;

        if (tree->count > 0) {
            tree->mean = (previous_mean * (tree->count + 1) - score) / tree->count;

            float new_variance = ((tree->stddev * tree->stddev * (tree->count + 1)) - 
                                  (score - previous_mean) * (score - tree->mean)) / 
                                  tree->count;
            tree->stddev = sqrt(new_variance);
        } else {
            tree->mean = 0;
            tree->stddev = 0;
        }
    } else {
        printf("record does not exist\n");
    }
}

JobID: cp264oc-202405-lab8-a8
Name: type your name here
ID: type your student ID here

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab8

T1 BST
T1.1 [2/2/*] Read and test BST example

T2 AVL trees
T2.1 [4/4/*] Read and test AVL examples

T3 Red-Black-tree
T3.1 [2/2/*] Read and test Red-Black-tree

T4 Splay trees
T4.1 [2/2/*] Read and test Splay tree

A8

Q1 [18/18/*] AVL tree and operations

Q2 [12/12/*] AVL tree for record data processing

Total: [40/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  

Q1 output:
------------------
Test: avl_insert

avl_insert(A01 10.0):A01 10.0
avl_insert(A02 20.0):A01 10.0 A02 20.0
avl_insert(A03 30.0):A01 10.0 A02 20.0 A03 30.0
avl_insert(A04 40.0):A01 10.0 A02 20.0 A03 30.0 A04 40.0
avl_insert(A05 50.0):A01 10.0 A02 20.0 A03 30.0 A04 40.0 A05 50.0
avl_insert(A06 60.0):A01 10.0 A02 20.0 A03 30.0 A04 40.0 A05 50.0 A06 60.0
avl_insert(A07 70.0):A01 10.0 A02 20.0 A03 30.0 A04 40.0 A05 50.0 A06 60.0 A07 70.0

|___:A04,40.0,2
    |___R:A06,60.0,1
        |___R:A07,70.0,0
        |___L:A05,50.0,0
    |___L:A02,20.0,1
        |___R:A03,30.0,0
        |___L:A01,10.0,0

height(A04): 2
balance_factor(A04): 0
is_avl(A04): 1
------------------
Test: avl_search

avl_search(A02): A02 20.0
avl_search(A04): A04 40.0
avl_search(A08): NULL

------------------
Test: avl_delete

avl_delete(A01): A02 20.0 A03 30.0 A04 40.0 A05 50.0 A06 60.0 A07 70.0 
avl_delete(A03): A02 20.0 A04 40.0 A05 50.0 A06 60.0 A07 70.0
avl_delete(A04): A02 20.0 A05 50.0 A06 60.0 A07 70.0
height(A05): 2
balance_factor(A05): -1
is_avl(A05): 1









Q2 output:

------------------
Test: merge_avl

is_avl(avlA): 1
is_avl(avlB): 1
merge_avl(avlA avlB): 1
------------------
Test: merge_avlds

display_stats(avldsA): count 10 mean 55.0 stddev 28.7
display_stats(avldsB): count 10 mean 55.0 stddev 28.7
display_stats(avldsC): count 20 mean 55.0 stddev 28.7
merge_avlds(avldsA avldsB)-display_stats(avldsA): count 20 mean 55.0 stddev 28.7
avldsA.count: 20
avldsA.mean: 55.0
avldsA.stddev: 28.7
avldsB.count: 0
avldsB.mean: 0.0
avldsA.count==avldsC.count: 1
avldsA.mean==avldsC.mean: 1
avldsA.stddev==avldsC.stddev: 1


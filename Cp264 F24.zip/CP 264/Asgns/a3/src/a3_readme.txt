JobID: cp264oc-202405-lab3-a3
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A3

Q1 [15/15/*] My string functions

Q2 [0/15/*] My word processing

Total: [0/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails the marking test.  

Q1 output:
------------------
Test: str_wc

str_wc('Abc  DEF'): 2
str_wc('  aBc   Def   '): 2
str_wc('  Toonie is the Canadian $2 coin. '): 5
str_wc('  Binary has 10 digits.  '): 3

------------------
Test: str_lower

str_lower('Abc  DEF'): 'abc  def'
str_lower('  aBc   Def   '): '  abc   def   '
str_lower('  Toonie is the Canadian $2 coin. '): '  toonie is the canadian $2 coin. '
str_lower('  Binary has 10 digits.  '): '  binary has 10 digits.  '

------------------
Test: str_trim

str_trim('Abc  DEF'): 'Abc DEF'
str_trim('  aBc   Def   '): 'aBc Def '
str_trim('  Toonie is the Canadian $2 coin. '): 'Toonie is the Canadian $2 coin. '
str_trim('  Binary has 10 digits.  '): 'Binary has 10 digits. '

------------------
Test: str_str

str_str('Abc  DEF' 'Abc'): 'Abc  DEF'
str_str('  aBc   Def   ' 'test'): 'null'
str_str('  Toonie is the Canadian $2 coin. ' 'Canadian'): 'Canadian $2 coin. '
str_str('  Binary has 10 digits.  ' '10'): '10 digits.  '

Q2 output:

------------------
Test: create_dictionary, contain_word

create_dictionary(): 122
contain_word(this): 1
contain_word(is): 1
contain_word(data): 0
contain_word(structure): 0

------------------
Test: process_words

line_count: 2
word_count: 10
keyword_count: 3
first: 1
test: 2
second: 1
/*
 * @author Nedma
 */ 
 
#include "mystring.h"
/*
 * @author Nedma
 */ 
 
#include <stdio.h>
#include <string.h>
#include <ctype.h>

/**
 * Count the number of words in a given simple string. A word starts with an 
 * English character and ends with a character of space, tab, comma, or period.
 *
 * @param s - char pointer to a string
 * @return - return the number of words. 
 */
int str_wc(char *s) {
    int count = 0;        // Word count
    int in_word = 0;     // Flag to indicate if we are in a word

    while (*s) {         // Loop until the end of the string
        // Check if the current character is a word character
        if (isalpha(*s)) {
            if (!in_word) {
                in_word = 1; // We are now in a word
                count++;     // Increment word count
            }
        } else if (*s == ' ' || *s == '\t' || *s == ',' || *s == '.') {
            in_word = 0; // We are no longer in a word
        }
        s++; // Move to the next character
    }
    return count; // Return the total word count
}

/**
 * Change every upper case English letter to its lower case in the string passed by s
 *
 * @param s - char pointer to a string
 * @return - return the number of actual flips.   
 */
int str_lower(char *s) {
    int flips = 0; // Count of flips
    while (*s) {
        if (isupper(*s)) {
            *s = tolower(*s); // Convert to lower case
            flips++; // Increment flip count
        }
        s++; // Move to the next character
    }
    return flips; // Return the count of flips
}

/**
 * Remove unnecessary space characters in a simple string passed by `s`
 *
 * @param s - char pointer to a string
 */
void str_trim(char *s) {
    char *src = s; // Source pointer
    char *dst = s; // Destination pointer

    // Skip leading spaces
    while (*src == ' ' || *src == '\t') {
        src++;
    }

    while (*src) {
        // If the current character is not a space or tab, copy it
        if (*src != ' ' && *src != '\t') {
            *dst++ = *src; // Copy character
        } else if (dst != s && *(dst - 1) != ' ') { 
            // Only add one space if the previous character was not a space
            *dst++ = ' ';
        }
        src++;
    }
    *dst = '\0'; // Null-terminate the trimmed string
}

/**
 * Check if string s1 contains string s2 as substring, return the pointer to
 *  the position of the first matched substring, otherwise NULL value 0.
 * 
 * @param s1 - pointer to string s1
 * @param s2 - pointer to string s2
 * @return - char pointer to the first matched substring in s1.
 */
char *str_str(char *s1, char *s2) {
    if (!*s2) return s1; // If s2 is empty, return s1

    char *p1, *p2; // Pointers for traversing s1 and s2
    for (; *s1; s1++) {
        p1 = s1; 
        p2 = s2;

        while (*p1 && *p2 && (*p1 == *p2)) {
            p1++;
            p2++;
        }
        if (!*p2) {
            return s1; // Found the substring
        }
    }
    return NULL; // Substring not found
}

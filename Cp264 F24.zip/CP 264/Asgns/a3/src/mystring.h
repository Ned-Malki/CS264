/*
 * @author Nedma
 */ 
 
#ifndef MYSTRING_H
#define MYSTRING_H

int str_wc(char *s);

int str_lower(char *s);

void str_trim(char *s);

char *str_str(char *s1, char *s2);

#endif
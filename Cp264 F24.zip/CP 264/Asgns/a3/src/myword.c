/*
 * @author Nedma
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "mystring.h"
#include "myword.h"

#define MAX_LINE_LEN 1000
#define MAX_WORDS 1000

int str_lower(char *s);
void str_trim(char *s);
char* str_str(char *s1, char *s2);

int create_dictionary(FILE *p, char *dictionary) {
	char line[MAX_LINE_LEN];
	const char delimiters[] = " .,\n\t\r";
	char *token;
	int count = 0;

	dictionary[0] = '\0';

	while (fgets(line, MAX_LINE_LEN, p) != NULL) {
		str_lower(line);
		token = strtok(line, delimiters);

		while (token != NULL) {
			strcat(dictionary, token);
			strcat(dictionary, ",");
			count++;
			token = strtok(NULL, delimiters);
		}
	}

	return count;
}

BOOLEAN contain_word(char *dictionary, char *word) {
	if (word == NULL || *word == '\0') {
		return FALSE;
	}

	char temp[24] = ",";
	strcat(temp, word);
	strcat(temp, ",");

	if (str_str(dictionary, temp) != NULL) {
		return TRUE;
	}

	return FALSE;
}

WORDSTATS process_words(FILE *fp, WORD *words, char *dictionary) {
	WORDSTATS ws = { 0 };
	char line[MAX_LINE_LEN];
	const char delimiters[] = " .,\n\t\r";
	char *token;

	while (fgets(line, MAX_LINE_LEN, fp) != NULL) {
		ws.line_count++;
		str_trim(line);
		str_lower(line);

		token = strtok(line, delimiters);
		while (token != NULL) {
			ws.word_count++;

			if (strlen(token) > 0 && !contain_word(dictionary, token)) {
				int found = FALSE;

				for (int i = 0; i < ws.keyword_count; i++) {
					if (strcmp(words[i].word, token) == 0) {
						words[i].count++;
						found = TRUE;
						break;
					}
				}

				if (!found && ws.keyword_count < MAX_WORDS) {
					strcpy(words[ws.keyword_count].word, token);
					words[ws.keyword_count].count = 1;
					ws.keyword_count++;
				}
			}
			token = strtok(NULL, delimiters);
		}
	}

	return ws;
}

// myword.h

#ifndef MYWORD_H
#define MYWORD_H

#include <stdio.h>

// Define BOOLEAN enumeration
typedef enum {
    FALSE = 0,
    TRUE = 1
} BOOLEAN;

// Define structure type WORD
typedef struct {
    char word[20]; // Stores the word (maximum 19 characters + null terminator)
    int count;     // Frequency of the word
} WORD;

// Define structure type WORDSTATS
typedef struct {
    int line_count;     // Number of lines
    int word_count;     // Total number of words
    int keyword_count;  // Number of unique non-common words
} WORDSTATS;

/*
 * Load word data from file, and insert words into a dictionary represented by char array.
 * 
 * @param fp -   File pointer to an opened text file
 * @param dictionary - Char pointer to a char array where dictionary words are stored. 
 *                      Words are stored sequentially separated by null terminators.
 * @return - The number of words added into the dictionary.   
 */
int create_dictionary(FILE *fp, char *dictionary);

/*
 * Determine if a given word is contained in the given dictionary.  
 * 
 * @param dictionary -  Char pointer to a char array of given dictionary.
 * @param word  -  Pointer to a given word.  
 *                     
 * @return - TRUE if the word is in the dictionary, FALSE otherwise.   
 */
BOOLEAN contain_word(char *dictionary, char *word);

/*
 * Process text data from a file for word statistic information of line count, word count, keyword count, and frequency of keywords.   
 * 
 * @param fp -  FILE pointer of input text data file.
 * @param words  -  WORD array for keywords and their frequencies.
 * @param dictionary  -  Stop-word/common-word dictionary.    
 *                     
 * @return - WORDSTATS value of processed word stats information.   
 */
WORDSTATS process_words(FILE *fp, WORD *words, char *dictionary);

#endif // MYWORD_H

JobID: cp264oc-202405-lab6-a6
Name: type your name here
ID: type your student ID here

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab6

T1 Queues
T1.1 [3/3/*] Read and test queue examples    

T2 Stacks
T2.1 [3/3/*] Read and test stack examples    

T3 Application of stacks
T3.1 [4/4/*] Read and test stack applications

A6

Q1 [8/8/*] linked list queue data structure

Q2 [8/8/*] linked list stack data structure

Q3 [14/14/*] Postfix and infix expression evaluation

Total: [40/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  



 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║   
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║   
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║   
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝   
                                                     
 ██████╗ ███╗   ██╗███████╗                          
██╔═══██╗████╗  ██║██╔════╝██╗                       
██║   ██║██╔██╗ ██║█████╗  ╚═╝                       
██║   ██║██║╚██╗██║██╔══╝  ██╗                       
╚██████╔╝██║ ╚████║███████╗╚═╝                       
 ╚═════╝ ╚═╝  ╚═══╝╚══════╝                          




------------------
Test: enqueue

enqueue((): length 1 data (
enqueue(2): length 2 data ( 2
enqueue(+): length 3 data ( 2 +
enqueue(3): length 4 data ( 2 + 3
enqueue()): length 5 data ( 2 + 3 )

------------------
Test: dequeue

given queue: length 5 data ( 2 + 3 )
dequeue() (: length 4 data 2 + 3 )
dequeue() 2: length 3 data + 3 )
dequeue() +: length 2 data 3 )
dequeue() 3: length 1 data )
dequeue() ): length 0 data





 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║   
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║   
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║   
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝   
                                                     
████████╗██╗    ██╗ ██████╗                          
╚══██╔══╝██║    ██║██╔═══██╗██╗                      
   ██║   ██║ █╗ ██║██║   ██║╚═╝                      
   ██║   ██║███╗██║██║   ██║██╗                      
   ██║   ╚███╔███╔╝╚██████╔╝╚═╝                      
   ╚═╝    ╚══╝╚══╝  ╚═════╝                          




------------------
Test: push

push(1): length 1 data 1
push(2): length 2 data 2 1
push(+): length 3 data + 2 1
push(3): length 4 data 3 + 2 1
push(a): length 5 data a 3 + 2 1

------------------
Test: pop

given stack: length 5 data a 3 + 2 1
pop() a: length 4 data 3 + 2 1
pop() 3: length 3 data + 2 1
pop() +: length 2 data 2 1
pop() 2: length 1 data 1
pop() 1: length 0 data




 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║   
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║   
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║   
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝   
                                                     
████████╗██╗  ██╗██████╗ ███████╗███████╗            
╚══██╔══╝██║  ██║██╔══██╗██╔════╝██╔════╝██╗         
   ██║   ███████║██████╔╝█████╗  █████╗  ╚═╝         
   ██║   ██╔══██║██╔══██╗██╔══╝  ██╔══╝  ██╗         
   ██║   ██║  ██║██║  ██║███████╗███████╗╚═╝         
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝            




------------------
Test: infix_to_postfix

infix_to_postfix(1+2): 1 2 +
infix_to_postfix((1+2*3)): 1 2 3 * + (
infix_to_postfix(10-((3*4)+8)/4): 10 3 4 * 8 + 4 / -

------------------
Test: evaluate_postfix

evaluate_postfix(1 2 +): 3
evaluate_postfix(1 2 3 * + (): 7
evaluate_postfix(10 3 4 * 8 + 4 / -): 5

------------------
Test: evaluate_infix

evaluate_infix(1+2): 3
evaluate_infix((1+2*3)): 7
evaluate_infix(10-((3*4)+8)/4): 5

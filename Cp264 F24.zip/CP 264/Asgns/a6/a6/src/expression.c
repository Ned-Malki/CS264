/*
 * @author Nedma
 * @version 26-10-2024
 */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"
#include "stack.h"
#include "expression.h"

/*
 * Determines the precedence of the operator.
 */
int get_priority(char operator) {
    switch (operator) {
        case '/':
        case '*':
        case '%':
            return 1;
        case '+':
        case '-':
            return 0;
        default:
            return -1;
    }
}

/*
 * Identifies the type of the character.
 */
int type(char character) {
    if (character >= '0' && character <= '9')
        return 0;
    if (character == '/' || character == '*' || character == '%' || character == '+' || character == '-')
        return 1;
    if (character == '(')
        return 2;
    if (character == ')')
        return 3;
    return 4;
}

QUEUE infix_to_postfix(char *infix_expression) {
    char *current = infix_expression;
    QUEUE postfix_queue = {0};
    STACK operator_stack = {0};
    int negative_sign = 1, number = 0;

    while (*current) {
        if (*current == '-' && (current == infix_expression || *(current - 1) == '(')) {
            // Handle negative sign for operands
            negative_sign = -1;
        } else if (*current >= '0' && *current <= '9') {
            number = *current - '0';
            while (*(current + 1) >= '0' && *(current + 1) <= '9') {
                number = number * 10 + (*(current + 1) - '0');
                current++;
            }
            enqueue(&postfix_queue, new_node(negative_sign * number, 0));
            negative_sign = 1;
        } else if (*current == '(') {
            push(&operator_stack, new_node(*current, 2));
        } else if (*current == ')') {
            NODE *temp_node = pop(&operator_stack);
            while (temp_node && temp_node->type != 2) {
                if (temp_node->type == 1) {
                    enqueue(&postfix_queue, temp_node);
                }
                temp_node = pop(&operator_stack);
            }
        } else if (type(*current) == 1) {
            while (operator_stack.top && get_priority(operator_stack.top->data) >= get_priority(*current)) {
                enqueue(&postfix_queue, pop(&operator_stack));
            }
            push(&operator_stack, new_node(*current, 1));
        }
        current++;
    }

    while (operator_stack.top) {
        enqueue(&postfix_queue, pop(&operator_stack));
    }

    return postfix_queue;
}

int evaluate_postfix(QUEUE postfix_queue) {
    NODE *node_ptr = postfix_queue.front;
    STACK eval_stack = {0};
    int node_type = 0;

    while (node_ptr) {
        node_type = node_ptr->type;
        if (node_type == 0) { // Operand
            push(&eval_stack, new_node(node_ptr->data, 0));
        } else if (node_type == 1) { // Operator
            NODE *operand2_node = pop(&eval_stack);
            NODE *operand1_node = pop(&eval_stack);
            int operand2 = operand2_node->data;
            int operand1 = operand1_node->data;
            int result = 0;

            switch (node_ptr->data) {
                case '+':
                    result = operand1 + operand2;
                    break;
                case '-':
                    result = operand1 - operand2;
                    break;
                case '*':
                    result = operand1 * operand2;
                    break;
                case '%':
                    result = operand1 % operand2;
                    break;
                case '/':
                    result = operand1 / operand2;
                    break;
                default:
                    // Handle unexpected operator
                    break;
            }
            push(&eval_stack, new_node(result, 0));
        }
        node_ptr = node_ptr->next;
    }

    int final_result = eval_stack.top->data;
    stack_clean(&eval_stack);
    return final_result;
}

int evaluate_infix(char *infix_expression) {
    QUEUE postfix = infix_to_postfix(infix_expression);
    return evaluate_postfix(postfix);
}

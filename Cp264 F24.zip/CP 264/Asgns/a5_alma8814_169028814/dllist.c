/*
 * your program signature
 */ 

#include <stdio.h>
#include <stdlib.h> 
#include "dllist.h"

// Function to create a new node
NODE *new_node(char data) {
    NODE *np = (NODE *)malloc(sizeof(NODE));
    if (np == NULL) {
        printf("Memory allocation failed\n");
        exit(1);  // Handle memory allocation failure
    }
    np->data = data;
    np->prev = NULL;
    np->next = NULL;
    return np;
}

// Insert node at the start of the DLL
void dll_insert_start(DLL *dllp, NODE *np) {
    if (dllp->start == NULL) {  // List is empty
        dllp->start = np;
        dllp->end = np;
    } else {
        np->next = dllp->start;
        dllp->start->prev = np;
        dllp->start = np;
    }
    dllp->length++;
}

// Insert node at the end of the DLL
void dll_insert_end(DLL *dllp, NODE *np) {
    if (dllp->end == NULL) {  // List is empty
        dllp->start = np;
        dllp->end = np;
    } else {
        np->prev = dllp->end;
        dllp->end->next = np;
        dllp->end = np;
    }
    dllp->length++;
}

// Delete the node at the start of the DLL
void dll_delete_start(DLL *dllp) {
    if (dllp->start == NULL) {
        return;  // List is already empty
    }
    NODE *temp = dllp->start;
    if (dllp->start == dllp->end) {  // Only one node in the list
        dllp->start = NULL;
        dllp->end = NULL;
    } else {
        dllp->start = dllp->start->next;
        dllp->start->prev = NULL;
    }
    free(temp);
    dllp->length--;
}



// Delete the node at the end of the DLL
void dll_delete_end(DLL *dllp) {
    if (dllp->end == NULL) {
        return;  // List is already empty
    }
    NODE *temp = dllp->end;
    if (dllp->start == dllp->end) {  // Only one node in the list
        dllp->start = NULL;
        dllp->end = NULL;
    } else {
        dllp->end = dllp->end->prev;
        dllp->end->next = NULL;
    }
    free(temp);
    dllp->length--;
}






// Clean the entire list
void dll_clean(DLL *dllp) {
    while (dllp->start != NULL) {
        dll_delete_start(dllp);  // Repeatedly delete the start node
    }
    dllp->length = 0;
}

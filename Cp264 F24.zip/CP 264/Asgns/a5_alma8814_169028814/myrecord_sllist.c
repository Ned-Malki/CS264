/*
 * @author Nedma
 * @version 2024-10-12
 */ 
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "myrecord_sllist.h"

// Search for a node by name
NODE *sll_search(SLL *sllp, char *name) {
    NODE *ptr = sllp->start;
    while (ptr != NULL) {
        if (strcmp(ptr->data.name, name) == 0) {
            return ptr;  // Return the node if the name matches
        }
        ptr = ptr->next;
    }
    return NULL;  // Return NULL if the name is not found
}

// Insert a new node at the start of the list
void sll_insert(SLL *sllp, char *name, float score) {
    NODE *new_node = (NODE *)malloc(sizeof(NODE));
    if (new_node == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    strcpy(new_node->data.name, name);  // Copy the name
    new_node->data.score = score;       // Set the score

    new_node->next = sllp->start;       // Insert at the start
    sllp->start = new_node;

    sllp->length++;  // Update the list length
}

// Delete a node by name
int sll_delete(SLL *sllp, char *name) {
    NODE *ptr = sllp->start;
    NODE *prev = NULL;

    while (ptr != NULL) {
        if (strcmp(ptr->data.name, name) == 0) {
            if (prev == NULL) {
                // The node to delete is the first node
                sllp->start = ptr->next;
            } else {
                // The node to delete is in the middle or end
                prev->next = ptr->next;
            }
            free(ptr);
            sllp->length--;  // Update the list length
            return 1;  // Return 1 to indicate success
        }
        prev = ptr;
        ptr = ptr->next;
    }
    return 0;  // Return 0 if the node with the given name is not found
}

// Clean the entire list
void sll_clean(SLL *sllp) {
    NODE *temp, *ptr = sllp->start;
    while (ptr != NULL) {
        temp = ptr;
        ptr = ptr->next;
        free(temp);  // Free each node
    }
    sllp->start = NULL;  // Reset the list
    sllp->length = 0;
}

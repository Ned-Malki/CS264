/*
 * your program signature
 */ 
 
#include <stdio.h>
#include <stdlib.h>
#include "bigint.h"

BIGINT bigint(char *p) {
  BIGINT bn = {0};
  if (p == NULL) 
    return bn;
  else if (!(*p >= '0' && *p <= '9')) {// not begin with digits 
    return bn;
  }
  else if (*p == '0' && *(p+1) == '\0') {// just "0"
    dll_insert_end(&bn, new_node(*p -'0'));
    return bn;
  }  
  else { 
    while (*p) {
      if (*p >= '0' && *p <= '9' ){
        dll_insert_end(&bn, new_node(*p -'0'));
      } else {
        dll_clean(&bn);
        break;
      }
      p++;
    }
    return bn;
  }
}

BIGINT bigint_add(BIGINT op1, BIGINT op2) {
    BIGINT result = {0};
    int carry = 0;
    
    NODE *node1 = op1.end;
    NODE *node2 = op2.end;

    while (node1 != NULL || node2 != NULL || carry > 0) {
        int val1 = (node1 != NULL) ? node1->data : 0;
        int val2 = (node2 != NULL) ? node2->data : 0;

        int sum = val1 + val2 + carry;
        carry = sum / 10;
        int digit = sum % 10;

        dll_insert_start(&result, new_node(digit));  // Insert at start to reverse result order

        if (node1 != NULL) node1 = node1->prev;
        if (node2 != NULL) node2 = node2->prev;
    }

    return result;
}


BIGINT bigint_fibonacci(int n) {
    if (n == 0) {
        return bigint("0");
    } else if (n == 1) {
        return bigint("1");
    }

    BIGINT fib1 = bigint("0");
    BIGINT fib2 = bigint("1");
    BIGINT fib_next;

    for (int i = 2; i <= n; i++) {
        fib_next = bigint_add(fib1, fib2);

        // Clean up previous fib1 and fib2 to avoid memory leaks
        dll_clean(&fib1);

        fib1 = fib2;
        fib2 = fib_next;
    }

    dll_clean(&fib1);  // Clean the last unused BIGINT
    return fib2;       // The result is stored in fib2
}

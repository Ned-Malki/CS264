JobID: cp264oc-202405-lab5-a5
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work. Yup!

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab5

T1 Simple/singly linked list
T1.1 [2/2/*] Test singly linked list examples

T2 Linked list design
T2.1 [2/2/*] Design and implement linked list

T3 Doubly linked list
T3.1 [3/3/*] Work on doubly linked list

T4 Circular linked list
T4.1 [3/3/*] Work on circular linked list

A5

Q1 [12/12/*] Record data processing by singly linked list

Q2 [10/10/*] Doubly linked list

Q3 [8/8/*] Big integer type

Total: [40/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  



 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║   
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║   
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║   
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝   
                                                     
 ██████╗ ███╗   ██╗███████╗                          
██╔═══██╗████╗  ██║██╔════╝                          
██║   ██║██╔██╗ ██║█████╗                            
██║   ██║██║╚██╗██║██╔══╝                            
╚██████╔╝██║ ╚████║███████╗                          
 ╚═════╝ ╚═╝  ╚═══╝╚══════╝                          





------------------
Test: ssl_insert

given linked list:length 0
sll_insert(A9 90.0): length 1 A9 90.0
sll_insert(A8 80.0): length 2 A8 80.0 A9 90.0
sll_insert(A7 70.0): length 3 A7 70.0 A8 80.0 A9 90.0
sll_insert(A6 60.0): length 4 A6 60.0 A7 70.0 A8 80.0 A9 90.0

------------------
Test: ssl_search

given linked list:length 10 A0 100.0 A9 90.0 A8 80.0 A7 70.0 A6 60.0 A5 50.0 A4 40.0 A3 30.0 A2 20.0 A1 10.0
sll_search(A1): A1 10.0
sll_search(A3): A3 30.0
sll_search(A5): A5 50.0
sll_search(A10): not found

------------------
Test: ssl_delete

given linked list:length 10 A0 100.0 A9 90.0 A8 80.0 A7 70.0 A6 60.0 A5 50.0 A4 40.0 A3 30.0 A2 20.0 A1 10.0
sll_delete(A2): length 9 A0 100.0 A9 90.0 A8 80.0 A7 70.0 A6 60.0 A5 50.0 A4 40.0 A3 30.0 A1 10.0
sll_delete(A4): length 8 A0 100.0 A9 90.0 A8 80.0 A7 70.0 A6 60.0 A5 50.0 A3 30.0 A1 10.0 
sll_delete(A6): length 7 A0 100.0 A9 90.0 A8 80.0 A7 70.0 A5 50.0 A3 30.0 A1 10.0 
sll_delete(A8): length 6 A0 100.0 A9 90.0 A7 70.0 A5 50.0 A3 30.0 A1 10.0 






 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║   
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║   
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║   
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝   
                                                     
████████╗██╗    ██╗ ██████╗                          
╚══██╔══╝██║    ██║██╔═══██╗                         
   ██║   ██║ █╗ ██║██║   ██║                         
   ██║   ██║███╗██║██║   ██║                         
   ██║   ╚███╔███╔╝╚██████╔╝                         
   ╚═╝    ╚══╝╚══╝  ╚═════╝                          




------------------
Test: new_node

new_node(A): A
new_node(B): B
new_node(C): C
new_node(D): D

------------------
Test: dll_insert_start

given dll: length 0 forward
dll_insert_start(A): length 1 forward A
dll_insert_start(B): length 2 forward B A
dll_insert_start(C): length 3 forward C B A
dll_insert_start(D): length 4 forward D C B A 

------------------
Test: dll_insert_end

given dll: length 0 forward
dll_insert_end(A): length 1 forward A
dll_insert_end(B): length 2 forward A B
dll_insert_end(C): length 3 forward A B C
dll_insert_end(D): length 4 forward A B C D
resulted dll: length 4 backward D C B A 

------------------
Test: dll_delete_start

given dll: length 4 forward D C B A
dll_delete_start(A): length 3 forward C B A
dll_delete_start(B): length 2 forward B A
dll_delete_start(C): length 1 forward A
dll_delete_start(D): length 0 forward 

------------------
Test: dll_delete_end

given dll: length 4 forward D C B A
dll_delete_end(A): length 3 forward D C B
dll_delete_end(B): length 2 forward D C
dll_delete_end(C): length 1 forward D
dll_delete_end(D): length 0 forward







 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║   
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║   
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║   
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝   
                                                     
████████╗██╗  ██╗██████╗ ███████╗███████╗            
╚══██╔══╝██║  ██║██╔══██╗██╔════╝██╔════╝            
   ██║   ███████║██████╔╝█████╗  █████╗              
   ██║   ██╔══██║██╔══██╗██╔══╝  ██╔══╝              
   ██║   ██║  ██║██║  ██║███████╗███████╗            
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝            



------------------
Test: bigint

bigint(111): 111
bigint(2222): 2222
bigint(666666666666): 666666666666
bigint(1111111111111111111): 1111111111111111111

------------------
Test: bigint_add

111+222:333
2222+3333:5555
666666666666+333333333334:1000000000000
1111111111111111111+8888888888888888889:10000000000000000000

------------------
Test: big_fibonacci

bigint_fibonacci(1): 1
bigint_fibonacci(2): 1
bigint_fibonacci(3): 2
bigint_fibonacci(10): 55
bigint_fibonacci(40): 102334155
bigint_fibonacci(100): 354224848179261915075


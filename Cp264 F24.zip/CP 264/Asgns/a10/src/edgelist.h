/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/

#ifndef EDGELIST_H
#define EDGELIST_H

typedef struct edgenode {
  int from;
  int to;
  int weight;
  struct edgenode *next;
} EDGENODE;


typedef struct edgelist {
  int size;    
  EDGENODE *start;
  EDGENODE *end;
} EDGELIST;

EDGELIST *new_edgelist();

void insert_edge_start(EDGELIST *g, int from, int to, int weight);

void insert_edge_end(EDGELIST *g, int from, int to, int weight);

void delete_edge(EDGELIST *g, int from, int to);

int edgelist_weight(EDGELIST *g);

void edgelist_clean(EDGELIST **gp);

#endif
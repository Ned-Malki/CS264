JobID: cp264oc-202405-lab10-a10
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab10

T1 Graph data structure and operations
T1.1 [4/4/*] Read & test graph data structure

T2 Minimum spanning tree
T2.1 [2/2/*] Read and test Kruskal algorithm 
T2.2 [2/2/*] Read and test Prim algorithm    

T3 Shortest path problem
T3.1 [2/2/*] Read and test Dijkstra algorithm

A10

Q1 [8/8/*] Edge list graph data structure

Q2 [10/10/*] Adjacency list graph data structure

Q3 [12/12/*] Graph algorithms

Total: [40/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  




 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗     ██╗       
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝    ███║    ██╗
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║       ╚██║    ╚═╝
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║        ██║    ██╗
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║        ██║    ╚═╝
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝        ╚═╝       





------------------
Test: new_edgelist

new_edgelist(): size 0 (from to weight) 
------------------
Test: insert_edge_start

insert_edge_start(0 2 3): size 1 (from to weight) (0 2 3) 
insert_edge_start(2 1 4): size 2 (from to weight) (2 1 4) (0 2 3)
insert_edge_start(1 3 9): size 3 (from to weight) (1 3 9) (2 1 4) (0 2 3)
insert_edge_start(1 4 11): size 4 (from to weight) (1 4 11) (1 3 9) (2 1 4) (0 2 3)

------------------
Test: insert_edge_end

insert_edge_end(0 2 3): size 1 (from to weight) (0 2 3) 
insert_edge_end(2 1 4): size 2 (from to weight) (0 2 3) (2 1 4)
insert_edge_end(1 3 9): size 3 (from to weight) (0 2 3) (2 1 4) (1 3 9)
insert_edge_end(1 4 11): size 4 (from to weight) (0 2 3) (2 1 4) (1 3 9) (1 4 11)

------------------
insert_edge_end(1 3 9): size 3 (from to weight) (0 2 3) (2 1 4) (1 3 9)
insert_edge_end(1 4 11): size 4 (from to weight) (0 2 3) (2 1 4) (1 3 9) (1 4 11)

------------------
Test: delete_edge

before delete: size 4 (from to weight) (0 2 3) (2 1 4) (1 3 9) (1 4 11)
delete_edge(2 1): size 3 (from to weight) (0 2 3) (1 3 9) (1 4 11)
delete_edge(1 3): size 2 (from to weight) (0 2 3) (1 4 11)
delete_edge(1 4): size 1 (from to weight) (0 2 3)
delete_edge(0 2): size 0 (from to weight)

------------------
Test: edgelist_weight

edgelist graph: size 4 (from to weight) (0 2 3) (2 1 4) (1 3 9) (1 4 11)
weight_edgelis(): 27









 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗    ██████╗        
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝    ╚════██╗    ██╗
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║        █████╔╝    ╚═╝
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║       ██╔═══╝     ██╗
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║       ███████╗    ╚═╝
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝       ╚══════╝       






------------------
Test: new_graph

display_graph(): order 5 size 0 (from to weight)
------------------
Test: insert_edge_graph

insert_edge_graph(0 1 7): order 5 size 1 (from to weight) (0 1 7)
insert_edge_graph(0 2 3): order 5 size 2 (from to weight) (0 1 7) (0 2 3) 
insert_edge_graph(1 2 4): order 5 size 3 (from to weight) (0 1 7) (0 2 3) (1 2 4)
insert_edge_graph(1 3 9): order 5 size 4 (from to weight) (0 1 7) (0 2 3) (1 2 4) (1 3 9)
insert_edge_graph(1 4 11): order 5 size 5 (from to weight) (0 1 7) (0 2 3) (1 2 4) (1 3 9) (1 4 11)
insert_edge_graph(2 3 10): order 5 size 6 (from to weight) (0 1 7) (0 2 3) (1 2 4) (1 3 9) (1 4 11) (2 3 10) 
------------------
Test: get_edge_weigh

get_edge_weight(0 1): 7
get_edge_weight(0 2): 3
get_edge_weight(1 2): 4
get_edge_weight(1 3): 9
get_edge_weight(1 4): 11
get_edge_weight(2 3): 10

------------------
Test: test_traverse_bforder

traverse_bforder(0): A B C D E

traverse_bforder(1): B C D E 

traverse_bforder(2): C D

traverse_bforder(3): D

traverse_bforder(4): E


------------------
Test: test_traverse_dforder

traverse_dforder(0): A C D B E

traverse_dforder(1): B E D C

traverse_dforder(2): C D

traverse_dforder(3): D

traverse_dforder(4): E


------------------
Test: test_delete_edge_graph

delete_edge_graph(0 1): order 5 size 5 (from to weight) (0 2 3) (1 2 4) (1 3 9) (1 4 11) (2 3 10) 
delete_edge_graph(0 2): order 5 size 4 (from to weight) (1 2 4) (1 3 9) (1 4 11) (2 3 10)
delete_edge_graph(1 2): order 5 size 3 (from to weight) (1 3 9) (1 4 11) (2 3 10)
delete_edge_graph(1 3): order 5 size 2 (from to weight) (1 4 11) (2 3 10)
delete_edge_graph(1 4): order 5 size 1 (from to weight) (2 3 10) 
delete_edge_graph(2 3): order 5 size 0 (from to weight)







 ██████╗ ██╗   ██╗████████╗██████╗ ██╗   ██╗████████╗    ██████╗        
██╔═══██╗██║   ██║╚══██╔══╝██╔══██╗██║   ██║╚══██╔══╝    ╚════██╗    ██╗
██║   ██║██║   ██║   ██║   ██████╔╝██║   ██║   ██║        █████╔╝    ╚═╝
██║   ██║██║   ██║   ██║   ██╔═══╝ ██║   ██║   ██║        ╚═══██╗    ██╗
╚██████╔╝╚██████╔╝   ██║   ██║     ╚██████╔╝   ██║       ██████╔╝    ╚═╝
 ╚═════╝  ╚═════╝    ╚═╝   ╚═╝      ╚═════╝    ╚═╝       ╚═════╝        


graph: order 5 size 12 (from to weight) (0 1 8) (0 2 3) (1 0 8) (1 2 4) (1 3 9) (1 4 11) (2 0 3) (2 1 4) (2 3 10) (3 2 10) (3 1 9) (4 1 11) 
------------------
Test: mst_prim

mst_prim(0): size 4 (from to weight) (2 1 4) (0 2 3) (1 3 9) (1 4 11)

mst weight:27

------------------
Test: spt_dijkstra

spt_dijkstra(0): size 5 (from to weight) (0 1 8) (0 2 3) (2 1 7) (2 3 13) (1 4 18) 

spt weight:49

------------------
Test: sp_dijkstra

sp_dijkstra(0 4): size 3 (from to weight) (0 2 3) (2 1 4) (1 4 11)

sp length:18
/*
 * your program signature
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "heap.h"

// Helper function to compare keys
int cmp(KEYTYPE a, KEYTYPE b) {
    if (a < b) return -1;
    else if (a > b) return 1;
    return 0;
}

// Create a new heap with given capacity
HEAP *new_heap(int capacity) {
    HEAP *hp = (HEAP*) malloc(sizeof(HEAP));
    if (hp == NULL) return NULL;
    hp->hda = (HEAPDATA *) malloc(sizeof(HEAPDATA) * capacity);
    if (hp->hda == NULL) {
        free(hp);
        return NULL;
    }
    hp->capacity = capacity;
    hp->size = 0;
    return hp;
}

// Helper function to maintain the heap property upwards
int heapify_up(HEAPDATA *hda, int index) {
    int parent = (index - 1) / 2;
    while (index > 0 && cmp(hda[index].key, hda[parent].key) < 0) {
        HEAPDATA temp = hda[index];
        hda[index] = hda[parent];
        hda[parent] = temp;

        index = parent;
        parent = (index - 1) / 2;
    }
    return index;
}

// Helper function to maintain the heap property downwards
int heapify_down(HEAPDATA *hda, int n, int index) {
    int smallest = index;
    int left = 2 * index + 1;
    int right = 2 * index + 2;

    if (left < n && cmp(hda[left].key, hda[smallest].key) < 0) {
        smallest = left;
    }
    if (right < n && cmp(hda[right].key, hda[smallest].key) < 0) {
        smallest = right;
    }
    if (smallest != index) {
        HEAPDATA temp = hda[index];
        hda[index] = hda[smallest];
        hda[smallest] = temp;

        heapify_down(hda, n, smallest);
    }
    return index;
}

// Insert a new node into the heap
void heap_insert(HEAP *heap, HEAPDATA new_node) {
    if (heap->size == heap->capacity) {
        printf("Heap overflow\n");
        return;
    }
    heap->hda[heap->size] = new_node;
    heapify_up(heap->hda, heap->size);
    heap->size++;
}

// Find the minimum element in the heap
HEAPDATA heap_find_min(HEAP *heap) {
    if (heap->size == 0) {
        printf("Heap is empty\n");
        HEAPDATA empty = {0, 0};
        return empty;
    }
    return heap->hda[0];
}

// Extract the minimum element from the heap
HEAPDATA heap_extract_min(HEAP *heap) {
    if (heap->size == 0) {
        printf("Heap is empty\n");
        HEAPDATA empty = {0, 0};
        return empty;
    }
    HEAPDATA min = heap->hda[0];
    heap->hda[0] = heap->hda[heap->size - 1];
    heap->size--;
    heapify_down(heap->hda, heap->size, 0);
    return min;
}

// Change the key of an element at a specific index
int heap_change_key(HEAP *heap, int index, KEYTYPE new_key) {
    if (index < 0 || index >= heap->size) {
        printf("Index out of range\n");
        return -1;
    }
    KEYTYPE old_key = heap->hda[index].key;
    heap->hda[index].key = new_key;

    if (cmp(new_key, old_key) < 0) {
        heapify_up(heap->hda, index);
    } else {
        heapify_down(heap->hda, heap->size, index);
    }
    return 0;
}

// Search for an element by its value
int heap_search_data(HEAP *heap, VALUETYPE data) {
    for (int i = 0; i < heap->size; i++) {
        if (heap->hda[i].value == data) {
            return i;
        }
    }
    return -1; // Not found
}

// Clean up the heap
void heap_clean(HEAP **heapp) {
    if (heapp && *heapp) {
        HEAP *heap = *heapp;
        if (heap->hda) {
            free(heap->hda);
        }
        free(heap);
        *heapp = NULL;
    }
}

/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graph.h"

/**
 * Create and return a new adjacency list graph of order `n`.
 *
 * @param n Number of nodes in the graph.
 * @return A pointer to the newly created graph structure.
 */
GRAPH *new_graph(int n) {
    GRAPH *g = (GRAPH *)malloc(sizeof(GRAPH));
    if (!g) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    g->order = n;
    g->size = 0;
    g->nodes = (GNODE **)malloc(n * sizeof(GNODE *));
    if (!g->nodes) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < n; i++) {
        g->nodes[i] = (GNODE *)malloc(sizeof(GNODE));
        if (!g->nodes[i]) {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }
        g->nodes[i]->nid = i;
        sprintf(g->nodes[i]->name, "Node%d", i);
        g->nodes[i]->neighbor = NULL;
    }
    return g;
}

/**
 * Add or update an edge `(from, to, weight)` in the graph.
 *
 * @param g Pointer to the graph.
 * @param from Source node ID.
 * @param to Destination node ID.
 * @param weight Weight of the edge.
 */
void insert_edge_graph(GRAPH *g, int from, int to, int weight) {
    if (!g || from >= g->order || to >= g->order) return;

    ADJNODE *current = g->nodes[from]->neighbor;
    ADJNODE *prev = NULL;

    while (current) {
        if (current->nid == to) {
            current->weight = weight; // Update weight if edge exists.
            return;
        }
        prev = current;
        current = current->next;
    }

    ADJNODE *new_node = (ADJNODE *)malloc(sizeof(ADJNODE));
    if (!new_node) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    new_node->nid = to;
    new_node->weight = weight;
    new_node->next = NULL;

    if (prev) {
        prev->next = new_node;
    } else {
        g->nodes[from]->neighbor = new_node;
    }
    g->size++;
}

/**
 * Delete an edge `(from, to)` from the graph.
 *
 * @param g Pointer to the graph.
 * @param from Source node ID.
 * @param to Destination node ID.
 */
void delete_edge_graph(GRAPH *g, int from, int to) {
    if (!g || from >= g->order || to >= g->order) return;

    ADJNODE *current = g->nodes[from]->neighbor;
    ADJNODE *prev = NULL;

    while (current) {
        if (current->nid == to) {
            if (prev) {
                prev->next = current->next;
            } else {
                g->nodes[from]->neighbor = current->next;
            }
            free(current);
            g->size--;
            return;
        }
        prev = current;
        current = current->next;
    }
}

/**
 * Get and return the weight of the edge `(from, to)` if it exists.
 *
 * @param g Pointer to the graph.
 * @param from Source node ID.
 * @param to Destination node ID.
 * @return Weight of the edge, or `INFINITY` if the edge does not exist.
 */
int get_edge_weight(GRAPH *g, int from, int to) {
    if (!g || from >= g->order || to >= g->order) return INFINITY;

    ADJNODE *current = g->nodes[from]->neighbor;
    while (current) {
        if (current->nid == to) {
            return current->weight;
        }
        current = current->next;
    }
    return INFINITY;
}

/**
 * Traverse graph nodes in breadth-first-order using an auxiliary queue.
 *
 * @param g Pointer to the graph.
 * @param start Starting node ID.
 */
void traverse_bforder(GRAPH *g, int start) {
    if (!g || start >= g->order) return;

    int *visited = (int *)calloc(g->order, sizeof(int));
    int *queue = (int *)malloc(g->order * sizeof(int));
    int front = 0, rear = 0;

    visited[start] = 1;
    queue[rear++] = start;

    while (front < rear) {
        int current = queue[front++];
        printf("%s ", g->nodes[current]->name);

        ADJNODE *neighbor = g->nodes[current]->neighbor;
        while (neighbor) {
            if (!visited[neighbor->nid]) {
                visited[neighbor->nid] = 1;
                queue[rear++] = neighbor->nid;
            }
            neighbor = neighbor->next;
        }
    }

    printf("\n");
    free(visited);
    free(queue);
}

/**
 * Traverse graph in depth-first-order using an auxiliary stack.
 *
 * @param g Pointer to the graph.
 * @param start Starting node ID.
 */
void traverse_dforder(GRAPH *g, int start) {
    if (!g || start >= g->order) return;

    int *visited = (int *)calloc(g->order, sizeof(int));
    int *stack = (int *)malloc(g->order * sizeof(int));
    int top = -1;

    stack[++top] = start;

    while (top >= 0) {
        int current = stack[top--];

        if (!visited[current]) {
            visited[current] = 1;
            printf("%s ", g->nodes[current]->name);

            ADJNODE *neighbor = g->nodes[current]->neighbor;
            while (neighbor) {
                if (!visited[neighbor->nid]) {
                    stack[++top] = neighbor->nid;
                }
                neighbor = neighbor->next;
            }
        }
    }

    printf("\n");
    free(visited);
    free(stack);
}

/**
 * Clean the graph by freeing all dynamically allocated memory.
 *
 * @param gp Pointer to the pointer of the graph to clean.
 */
void graph_clean(GRAPH **gp) {
    if (!gp || !(*gp)) return;

    for (int i = 0; i < (*gp)->order; i++) {
        ADJNODE *current = (*gp)->nodes[i]->neighbor;
        while (current) {
            ADJNODE *next = current->next;
            free(current);
            current = next;
        }
        free((*gp)->nodes[i]);
    }
    free((*gp)->nodes);
    free(*gp);
    *gp = NULL;
}

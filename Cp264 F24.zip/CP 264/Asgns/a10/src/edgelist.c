/*
*    _____     _   _           _                          _    _                 _ _    _   ____   ___ ____  _  _   
*   / ___ \   | \ | | __ _  __| | ___  ___ _ __ ___      / \  | |_ __ ___   __ _| | | _(_) |___ \ / _ \___ \| || |  
*  / / __| \  |  \| |/ _` |/ _` |/ _ \/ _ \ '_ ` _ \    / _ \ | | '_ ` _ \ / _` | | |/ / |   __| | | | |__| | || |_ 
* | | |__   | | |\  | |_| | |_| |  __/  __/ | | | | |  / ___ \| | | | | | | |_| | |   <| |  / __/| |_| / __/|__   _|
*  \ \___| /  |_| \_|\__,_|\__,_|\___|\___|_| |_| |_| /_/   \_\_|_| |_| |_|\__,_|_|_|\_\_| |_____|\___/_____|  |_|  
*   \_____/                                                                                                         
*/

#include <stdio.h>
#include <stdlib.h>
#include "edgelist.h"


/**
 * Create and return a new edge list graph.
 * 
 * @return A pointer to the newly created EDGELIST structure.
 */
EDGELIST *new_edgelist() {
    EDGELIST *g = (EDGELIST *)malloc(sizeof(EDGELIST));
    if (!g) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    g->size = 0;
    g->start = NULL;
    g->end = NULL;
    return g;
}

/**
 * Add a new edge at the start of the linked list of edges.
 *
 * @param g Pointer to the edge list graph.
 * @param from Index of the source vertex.
 * @param to Index of the destination vertex.
 * @param weight Weight of the edge.
 */
void insert_edge_start(EDGELIST *g, int from, int to, int weight) {
    if (!g) return;
    EDGENODE *new_edge = (EDGENODE *)malloc(sizeof(EDGENODE));
    if (!new_edge) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    new_edge->from = from;
    new_edge->to = to;
    new_edge->weight = weight;
    new_edge->next = g->start;

    g->start = new_edge;
    if (g->size == 0) {
        g->end = new_edge;
    }
    g->size++;
}

/**
 * Add a new edge at the end of the linked list of edges.
 *
 * @param g Pointer to the edge list graph.
 * @param from Index of the source vertex.
 * @param to Index of the destination vertex.
 * @param weight Weight of the edge.
 */
void insert_edge_end(EDGELIST *g, int from, int to, int weight) {
    if (!g) return;
    EDGENODE *new_edge = (EDGENODE *)malloc(sizeof(EDGENODE));
    if (!new_edge) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    new_edge->from = from;
    new_edge->to = to;
    new_edge->weight = weight;
    new_edge->next = NULL;

    if (g->size == 0) {
        g->start = new_edge;
        g->end = new_edge;
    } else {
        g->end->next = new_edge;
        g->end = new_edge;
    }
    g->size++;
}

/**
 * Delete an edge from the edge list graph.
 *
 * @param g Pointer to the edge list graph.
 * @param from Index of the source vertex of the edge to delete.
 * @param to Index of the destination vertex of the edge to delete.
 */
void delete_edge(EDGELIST *g, int from, int to) {
    if (!g || g->size == 0) return;

    EDGENODE *current = g->start;
    EDGENODE *prev = NULL;

    while (current) {
        if (current->from == from && current->to == to) {
            if (prev) {
                prev->next = current->next;
            } else {
                g->start = current->next;
            }
            if (current == g->end) {
                g->end = prev;
            }
            free(current);
            g->size--;
            return;
        }
        prev = current;
        current = current->next;
    }
}

/**
 * Calculate and return the total weight of all edges in the graph.
 *
 * @param g Pointer to the edge list graph.
 * @return The total weight of the edges in the graph.
 */
int edgelist_weight(EDGELIST *g) {
    if (!g || g->size == 0) return 0;

    int total_weight = 0;
    EDGENODE *current = g->start;

    while (current) {
        total_weight += current->weight;
        current = current->next;
    }
    return total_weight;
}

/**
 * Clean the graph by freeing all dynamically allocated memory.
 *
 * @param gp Pointer to the pointer of the edge list graph to clean.
 */
void edgelist_clean(EDGELIST **gp) {
    if (!gp || !(*gp)) return;

    EDGENODE *current = (*gp)->start;
    while (current) {
        EDGENODE *next = current->next;
        free(current);
        current = next;
    }
    free(*gp);
    *gp = NULL;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "mysort.h"
#include "myrecord.h"

#define MAX_LINE 100

/*
 * Comparison function to sort RECORDs by score for use with qsort.
 */
int compare_records(const void *a, const void *b) {
    RECORD *recordA = (RECORD *)a;
    RECORD *recordB = (RECORD *)b;
    if (recordA->score < recordB->score) return -1;
    if (recordA->score > recordB->score) return 1;
    return 0;
}

/*
 * Convert a percentage grade to letter grade defined by percentage ranges
 * A+=[90, 100], A=[85, 90), A-=[80, 85), B+=[77, 80), B=[73, 77), B-=[70, 73),
 * C+=[67, 70), C=[63, 67), C-=[60, 63), D+=[57, 60), D=[53, 57), D-=[50, 53), F=[0, 50).
 *
 * @param score - percentage grade.
 * @return - letter grade wrapped in GRADE structure type.
 */
GRADE grade(float score) {
    GRADE g;

    if (score >= 90) {
        strcpy(g.letter_grade, "A+");
    } else if (score >= 85) {
        strcpy(g.letter_grade, "A");
    } else if (score >= 80) {
        strcpy(g.letter_grade, "A-");
    } else if (score >= 77) {
        strcpy(g.letter_grade, "B+");
    } else if (score >= 73) {
        strcpy(g.letter_grade, "B");
    } else if (score >= 70) {
        strcpy(g.letter_grade, "B-");
    } else if (score >= 67) {
        strcpy(g.letter_grade, "C+");
    } else if (score >= 63) {
        strcpy(g.letter_grade, "C");
    } else if (score >= 60) {
        strcpy(g.letter_grade, "C-");
    } else if (score >= 57) {
        strcpy(g.letter_grade, "D+");
    } else if (score >= 53) {
        strcpy(g.letter_grade, "D");
    } else if (score >= 50) {
        strcpy(g.letter_grade, "D-");
    } else {
        strcpy(g.letter_grade, "F");
    }

    return g;
}

/*
 * Import record data from file and retrieves and stores all record entries
 * in the RECORD array passed by records, and returns the number of record count.
 *
 * @param *fp - FILE pointer to input file.
 * @param dataset - array of RECORD type to store record data.
 * @return - number of record count
 */
int import_data(FILE *fp, RECORD *dataset) {
    char delimiters[] = ",\n\r";
    char line[MAX_LINE];
    int i = 0; // record counter
    char *token = NULL;

    while (fgets(line, sizeof(line), fp) != NULL) {
        token = strtok(line, delimiters);
        strcpy(dataset[i].name, token);
        token = strtok(NULL, delimiters);
        sscanf(token, "%f", &dataset[i].score);
        i++;
    }

    return i;
}

/*
 * Take the RECORD data array as input, compute the average score, standard deviation,
 * median of the score values of the record data, and returns the results in STATS type.
 *
 * @param dataset - input record data array.
 * @param count - the number of data record in dataset array.
 * @return - stats value in STATS type.
 */
STATS process_data(RECORD *dataset, int count) {
    STATS stats;
    float sum = 0.0, sum_squared = 0.0;
    
    // Calculate mean
    for (int i = 0; i < count; i++) {
        sum += dataset[i].score;
    }
    stats.mean = sum / count;

    // Calculate standard deviation
    for (int i = 0; i < count; i++) {
        sum_squared += pow(dataset[i].score - stats.mean, 2);
    }
    stats.stddev = sqrt(sum_squared / count);

    // Sort the records by score for median calculation using qsort
    qsort(dataset, count, sizeof(RECORD), compare_records);

    // Calculate median
    if (count % 2 == 0) {
        stats.median = (dataset[count / 2 - 1].score + dataset[count / 2].score) / 2;
    } else {
        stats.median = dataset[count / 2].score;
    }

    stats.count = count;
    return stats;
}

/*
 * This function takes output file named outfilename, 
 * RECORD array by records, and outputs stats information,
 * and processed record data to files in required format.
 *
 * @param *fp - FILE pointer to output file.
 * @param dataset - array of RECORD type to store record data.
 * @param count - the number of data record in dataset array.
 * @return - returns 1 if successful; 0 if count < 1
 */

int report_data(FILE *fp, RECORD *dataset, int count) {
    if (count < 1) {
        return 0;
    }

    // Process the data to get statistics (though we don't need to print them)
    process_data(dataset, count);

    // Print records in the desired format: Name,Score,Grade
    for (int i = 0; i < count; i++) {
        GRADE g = grade(dataset[i].score);
        fprintf(fp, "%s,%.1f,%s\n", dataset[i].name, dataset[i].score, g.letter_grade);
    }

    return 1;
}


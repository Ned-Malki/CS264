/*
 * @author Nedma
 * @date 01/10/2024
 */ 

#ifndef MYSORT_H
#define MYSORT_H 

void selection_sort(float *a[], int left, int right);

void quick_sort(float *a[], int left, int right);

#endif
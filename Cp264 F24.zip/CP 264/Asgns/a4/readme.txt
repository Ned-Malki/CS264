JobID: cp264oc-202405-lab4-a4
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab4

T1 Induction proof
T1.1 [2/2/*] Write induction proof           

T2 Big-O notation
T2.1 [2/2/*] Prove Big-O statements          

T3 Build tool for complex C programs
T3.1 [0/0/*] Build all by one command        
T3.2 [0/0/*] Build incrementally             
T3.3 [1/1/*] Build static library            
T3.4 [2/2/*] Build using make                

T4 Sorting algorithms and analysis
T4.1 [2/2/*] Read and test sorting examples  
T4.2 [1/1/*] Merge sorting complexity proof  

A4

Q1 [12/12/*] Sorting algorithms

Q2 [18/18/*] Record data processing

Total: [40/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  


  ___                  _   _               _ 
 / _ \ _   _  ___  ___| |_(_) ___  _ __   / |
| | | | | | |/ _ \/ __| __| |/ _ \| '_ \  | |
| |_| | |_| |  __/\__ \ |_| | (_) | | | | | |
 \__\_\\__,_|\___||___/\__|_|\___/|_| |_| |_|
 / _ \ _   _| |_ _ __  _   _| |_ _           
| | | | | | | __| '_ \| | | | __(_)          
| |_| | |_| | |_| |_| | |_| | |_ _           
 \___/ \__,_|\__| .__/ \__,_|\__(_)       
                |_|                   


------------------
Test: selection_sort

selection_sort(5 4 3 2 1): 5 4 3 2 1
is_sorted(5 4 3 2 1): 1
selection_sort(3 1 4 1 5): 5 4 3 1 1
is_sorted(5 4 3 1 1): 1
selection_sort(3 1 4 5 2 7 6 9 8 0): 9 8 7 6 5 4 3 2 1 0
is_sorted(9 8 7 6 5 4 3 2 1 0): 1
selection_sort(1 4 2 8 5 7): 8 7 5 4 2 1
is_sorted(8 7 5 4 2 1): 1

------------------
Test: quick_sort

selection_sort(5 4 3 2 1): 5 4 3 2 1
is_sorted(5 4 3 2 1): 1
selection_sort(3 1 4 1 5): 5 4 3 1 1
is_sorted(5 4 3 1 1): 1
selection_sort(3 1 4 5 2 7 6 9 8 0): 9 8 7 6 5 4 3 2 1 0
is_sorted(9 8 7 6 5 4 3 2 1 0): 1
selection_sort(1 4 2 8 5 7): 8 7 5 4 2 1
is_sorted(8 7 5 4 2 1): 1

------------------
Test: sorting time and comparison

Algorithm runtime testing:
time_span(select_sort(10000 numbers) for 100 times)(ms):6716.0
time_span(quick_sort(10000 numbers) for 1000 times)(ms):802.0
time_span(select_sort(10000 numbers))/time_span(quick_sort(10000 numbers)):837.4




  ___                  _   _               ____  
 / _ \ _   _  ___  ___| |_(_) ___  _ __   |___ \ 
| | | | | | |/ _ \/ __| __| |/ _ \| '_ \    __| |
| |_| | |_| |  __/\__ \ |_| | (_) | | | |  / __/ 
 \__\_\\__,_|\___||___/\__|_|\___/|_| |_| |_____|
 / _ \ _   _| |_ _ __  _   _| |_ _               
| | | | | | | __| '_ \| | | | __(_)              
| |_| | |_| | |_| |_| | |_| | |_ _               
 \___/ \__,_|\__| .__/ \__,_|\__(_)              
                |_|                              




------------------
Test: grade

grade(45.7): F
grade(50.0): D-
grade(55.0): D
grade(59.0): D+
grade(61.0): C-
grade(63.0): C
grade(67.2): C+
grade(72.0): B-
grade(76.0): B
grade(79.0): B+
grade(80.5): A-
grade(85.0): A
grade(93.6): A+

------------------
Test: import_data

import_data():10
A0        10.0
A1        20.0
A2        30.0
A3        40.0
A4        50.0
A5        60.0
A6        70.0
A7        80.0
A8        90.0
A9        100.0

------------------
Test: process_data

count     10
mean      55.0
stddev    28.7
median    55.0

------------------
Test: report_data

A0,10.0,F
A1,20.0,F
A2,30.0,F
A3,40.0,F
A4,50.0,D-
A5,60.0,C-
A6,70.0,B-
A7,80.0,A-
A8,90.0,A+
A9,100.0,A+
/*
 * @Author Nedma
 */ 

#include "mysort.h"

/**
 * Use selection sort algorithm to sort array of float pointers such that
 * their pointed values are in decreasing order.
 *
 * @param *a[] - array of float pointers.
 * @param left - the start index of float pointer in array.
 * @param right - the end index of float pointer in array
 */
void selection_sort(float *a[], int left, int right) {
    int i, j, k;
    float *temp;

    for (i = left; i < right; ++i) {
        k = i;
        for (j = i + 1; j <= right; ++j) {
            if (*a[j] > *a[k]) {
                k = j;
            }
        }
        if (i != k) { // Swap a[i] and a[k]
            temp = a[k];
            a[k] = a[i];
            a[i] = temp;
        }
    }
}

/**
 * Use quick sort algorithm to sort array of float pointers such that
 * their pointed values are in decreasing order.
 *
 * @param *a[] - array of float pointers.
 * @param left - the start index of float pointer in array.
 * @param right - the end index of float pointer in array
 */
void quick_sort(float *a[], int left, int right) {
    if (left < right) {
        float *pivot = a[right]; // Choosing the rightmost element as pivot
        int i = left - 1;

        for (int j = left; j < right; ++j) {
            if (*a[j] > *pivot) { // Compare pointed values
                i++;
                float *temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }

        // Place the pivot in the correct position
        float *temp = a[i + 1];
        a[i + 1] = a[right];
        a[right] = temp;

        int partition_index = i + 1;

        // Recursively sort elements before and after partition
        quick_sort(a, left, partition_index - 1);
        quick_sort(a, partition_index + 1, right);
    }
}

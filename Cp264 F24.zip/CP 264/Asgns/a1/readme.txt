JobID: cp264oc-202405-lab1-a1
Name: Nadeem Almalki
ID: 169028814

Statement: I claim that the enclosed submission is my individual work.
Je dis que tout que sont dans ce submission sont mes travails individuels.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab1

T1 Install and test GCC compiler
T1.1 [0/0/*] Utlity programs
T1.2 [0/0/*] Visual Studio Code
T1.3 [1/1/*] Install GNU GCC compiler
T1.4 [1/1/*] Test GCC compiler

T2 Programming using IDE
T2.1 [1/1/*] VS code for C
T2.2 [1/1/*] C project on Eclipse

T3 Explore C programs
T3.1 [1/1/*] Program structures and organization
T3.2 [1/1/*] Basics data types and variables
T3.3 [1/1/*] Arithmetic operations, casting
T3.4 [1/1/*] Bit operations
T3.5 [1/1/*] Flow control examples
T3.6 [1/1/*] Function examples

A1

Q1 [0/10/*] Char type and operations

Q2 [0/10/*] Simple power sum

Q3 [0/10/*] Real roots of quadratic equation

Total: [0/40/*]

=======================================================================      
Copy and paste the console output of your public test in the following. 
This will help markers to mark your program if it fails marking test.  

Q1 output:


Q2 output:


Q3 output:



